#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 60

####################################
# Services
####################################
su -c "stop logcat logcatd logd tcpdump cnss_diag statsd traced idd-logreader idd-logreadermain stats dumpstate aplogd"

####################################
# Useless Services 
####################################
su -c "pm disable com.google.android.gms/.chimera.GmsIntentOperationService"
su -c "pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver"

####################################
# System Log
####################################
su -c "pm uninstall --user 0 com.android.traceur"

####################################
# Kernel Debugging (thx to KTSR)
####################################
for i in 'debug_mask' 'log_level*' 'debug_level*' '*debug_mode' 'edac_mc_log*' 'enable_event_log' '*log_level*' '*log_ue*' '*log_ce*' 'log_ecn_error' 'snapshot_crashdumper' 'seclog*' 'compat-log' '*log_enabled' 'tracing_on' 'mballoc_debug'; do
    for o in $(find /sys/ -type f -name "$i"); do
        echo '0' > "$o"
    done
done

echo "0" > "/proc/sys/kernel/sched_schedstats"

####################################
# CRC
####################################
for parameters in /sys/module/mmc_core/parameters/*; do
    echo '0' > "$parameters/use_spi_crc"
    echo '0' > "$parameters/removable"
    echo '0' > "$parameters/crc"
done

####################################
# Printk (thx to KNTD-reborn)
####################################
echo '0 0 0 0' > "/proc/sys/kernel/printk"
echo '0' > "/sys/module/printk/parameters/cpu"
echo '1' > "/sys/module/printk/parameters/console_suspend"
echo '0' > "/sys/kernel/printk_mode/printk_mode"
echo '1' > "/sys/module/printk/parameters/ignore_loglevel"
echo '0' > "/sys/module/printk/parameters/pid"
echo '0' > "/sys/module/printk/parameters/time"
echo '0' > "/sys/module/printk/parameters/printk_ratelimit"
echo 'off' > "/proc/sys/kernel/printk_devkmsg"

####################################
# Ramdumps
####################################
for parameters in /sys/module/subsystem_restart/parameters; do
    echo '0' > "$parameters/enable_ramdumps"
    echo '0' > "$parameters/enable_mini_ramdumps"
done

####################################
# Touchboost
####################################
echo '0' > '/sys/module/msm_performance/parameters/touchboost'
echo '0' > '/sys/power/pnpmgr/touch_boost'

####################################
# Adreno Idler
####################################
echo '0' > '/sys/module/adreno_idler/parameters/adreno_idler_active'

####################################
# Stune Boost
####################################
for stune in /dev/stune; do
    echo "0" > "$stune/background/schedtune.boost"
    echo "0" > "$stune/background/schedtune.colocate"
    echo "0" > "$stune/background/schedtune.prefer_idle"
    echo "0" > "$stune/background/schedtune.sched_boost"
    echo "1" > "$stune/background/schedtune.sched_boost_no_override"
    echo "0" > "$stune/background/schedtune.prefer_perf"
    echo "0" > "$stune/background/schedtune.util_est_en"
    echo "0" > "$stune/background/schedtune.ontime_en"
    echo "0" > "$stune/background/schedtune.prefer_high_cap"
    echo "0" > "$stune/foreground/schedtune.boost"
    echo "0" > "$stune/foreground/schedtune.colocate"
    echo "1" > "$stune/foreground/schedtune.prefer_idle"
    echo "0" > "$stune/foreground/schedtune.sched_boost"
    echo "1" > "$stune/foreground/schedtune.sched_boost_no_override"
    echo "0" > "$stune/foreground/schedtune.prefer_perf"
    echo "0" > "$stune/foreground/schedtune.util_est_en"
    echo "0" > "$stune/foreground/schedtune.ontime_en"
    echo "0" > "$stune/foreground/schedtune.prefer_high_cap"
    echo "0" > "$stune/nnapi-hal/schedtune.boost"
    echo "0" > "$stune/nnapi-hal/schedtune.colocate"
    echo "1" > "$stune/nnapi-hal/schedtune.prefer_idle"
    echo "0" > "$stune/nnapi-hal/schedtune.sched_boost"
    echo "1" > "$stune/nnapi-hal/schedtune.sched_boost_no_override"
    echo "0" > "$stune/nnapi-hal/schedtune.prefer_perf"
    echo "0" > "$stune/nnapi-hal/schedtune.util_est_en"
    echo "0" > "$stune/nnapi-hal/schedtune.ontime_en"
    echo "0" > "$stune/nnapi-hal/schedtune.prefer_high_cap"
    echo "0" > "$stune/rt/schedtune.boost"
    echo "0" > "$stune/rt/schedtune.colocate"
    echo "0" > "$stune/rt/schedtune.prefer_idle"
    echo "0" > "$stune/rt/schedtune.sched_boost"
    echo "1" > "$stune/rt/schedtune.sched_boost_no_override"
    echo "0" > "$stune/rt/schedtune.prefer_perf"
    echo "0" > "$stune/rt/schedtune.util_est_en"
    echo "0" > "$stune/rt/schedtune.ontime_en"
    echo "0" > "$stune/rt/schedtune.prefer_high_cap"
    echo "0" > "$stune/camera-daemon/schedtune.boost"
    echo "0" > "$stune/camera-daemon/schedtune.colocate"
    echo "1" > "$stune/camera-daemon/schedtune.prefer_idle"
    echo "0" > "$stune/camera-daemon/schedtune.sched_boost"
    echo "1" > "$stune/camera-daemon/schedtune.sched_boost_no_override"
    echo "0" > "$stune/camera-daemon/schedtune.prefer_perf"
    echo "0" > "$stune/camera-daemon/schedtune.util_est_en"
    echo "0" > "$stune/camera-daemon/schedtune.ontime_en"
    echo "1" > "$stune/camera-daemon/schedtune.prefer_high_cap"
    echo "1" > "$stune/top-app/schedtune.boost"
    echo "1" > "$stune/top-app/schedtune.colocate"
    echo "1" > "$stune/top-app/schedtune.prefer_idle"
    echo "0" > "$stune/top-app/schedtune.sched_boost"
    echo "1" > "$stune/top-app/schedtune.sched_boost_no_override"
    echo "1" > "$stune/top-app/schedtune.prefer_perf"
    echo "1" > "$stune/top-app/schedtune.util_est_en"
    echo "1" > "$stune/top-app/schedtune.ontime_en"
    echo "1" > "$stune/top-app/schedtune.prefer_high_cap"
    echo "0" > "$stune/schedtune.boost"
    echo "0" > "$stune/schedtune.colocate"
    echo "0" > "$stune/schedtune.prefer_idle"
    echo "0" > "$stune/schedtune.sched_boost"
    echo "0" > "$stune/schedtune.sched_boost_no_override"
    echo "0" > "$stune/schedtune.prefer_perf"
    echo "0" > "$stune/schedtune.util_est_en"
    echo "0" > "$stune/schedtune.ontime_en"
    echo "0" > "$stune/schedtune.prefer_high_cap"
done

####################################
# CPUset
####################################
for cpu_set in /dev/cpuset; do
    echo "0-7" > "$cpu_set/cpus"
    echo "0-7" > "$cpu_set/effective_cpus"
    echo "0-1" > "$cpu_set/background/cpus"
    echo "0-1" > "$cpu_set/background/effective_cpus"
    echo "0-2" > "$cpu_set/system-background/cpus"
    echo "0-2" > "$cpu_set/system-background/effective_cpus"
    echo "0-2,4-6" > "$cpu_set/foreground/cpus"
    echo "0-2,4-6" > "$cpu_set/foreground/effective_cpus"
    echo "0-7" > "$cpu_set/top-app/cpus"
    echo "0-7" > "$cpu_set/top-app/effective_cpus"
    echo "0-3" > "$cpu_set/restricted/cpus"
    echo "0-3" > "$cpu_set/restricted/effective_cpus"
    echo "0-3" > "$cpu_set/camera-daemon/cpus"
    echo "0-3" > "$cpu_set/camera-daemon/effective_cpus"
    echo "0-3" > "$cpu_set/camera-daemon-dedicated/cpus"
    echo "0-3" > "$cpu_set/camera-daemon-dedicated/effective_cpus"
done

####################################
# Virtual Memory
####################################
for virtual_memory in /proc/sys/vm/*; do
    echo '10' > "$virtual_memory/stat_interval"
    echo '0' > "$virtual_memory/page-cluster"
    echo '0' > "$virtual_memory/panic_on_oom"
    echo '3' > "$virtual_memory/drop_caches"
done

####################################
# LPM Levels
####################################
for parameters in /sys/module/lpm_levels/parameters/*; do
    echo '0' > "$parameters/sleep_disabled"
    echo '0' > "$parameters/lpm_prediction"
    echo '0' > "$parameters/lpm_ipi_prediction"
done

####################################
# File System
####################################
for fs in /proc/sys/fs; do
    echo '0' > "$fs/dir-notify-enable"
    echo '0' > "$fs/by-name/userdata/iostat_enable"
done

####################################
# I/O
####################################
for queue in /sys/block/*/queue; do
    echo '0' > "$queue/iostats"
    echo '128' > "$queue/read_ahead_kb"
    echo '64' > "$queue/nr_requests"
done

####################################
# GPU
####################################
for gpu in /sys/class/kgsl/kgsl-3d0; do
    echo '0' > "$gpu/adrenoboost"
    echo '0' > "$gpu/devfreq/adrenoboost"
    echo 'N' > "$gpu/adreno_idler_active"
done

####################################
# IPV4
####################################
for ipv4 in /proc/sys/net/ipv4; do
    echo "1" > "$ipv4/tcp_ecn"
    echo "3" > "$ipv4/tcp_fastopen"
    echo "0" > "$ipv4/tcp_syncookies"
done

####################################
# Battery
####################################
for sys in /sys; do
    echo 'Y' > "$sys/module/battery_saver/parameters/enabled"
    echo 'Y' > "$sys/module/workqueue/parameters/power_efficient"
    echo '1' > "$sys/devices/system/cpu/sched_mc_power_savings"
    echo 'deep' > "$sys/power/mem_sleep"
done

####################################
# Miscellaneous
####################################
for kernel in /proc/sys/kernel; do
    echo '5000000' > "$kernel/sched_migration_cost_ns"
    echo '1' > "$kernel/sched_child_runs_first"
    echo '1' > "$kernel/sched_autogroup_enabled"
    echo '0' > "$kernel/sched_tunable_scaling"
    echo '0' > "$kernel/hung_task_timeout_secs"
    echo '5' > "$kernel/perf_cpu_time_max_percent"
    echo '1' > "$kernel/timer_migration"
done

####################################
# Fstrim
####################################
su -c 'fstrim -v /data /system /cache /vendor /product /preload /metadata /odm /system_ext'

exit 0