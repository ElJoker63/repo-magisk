UPDATE MODULE MAGISK :

[Download](https://github.com/KutuMobaa/X-MOD/releases/download/X-MOD/X-MOD.Module.Magisk.V6.2.zip)

#### X-MOD Module Magisk V6.2 :

* Menambahkan Pilihan Pada Fitur Thermal, Sekarang Pengguna Dapat Memilih Menggunakan Thermal Extreme Atau Standar.

* Menambahkan Fitur I/O Scheduler Untuk Meningkatkan Performa Yang Lebih Baik Disaat Bermain Game.
I/O Dapat Disesuaikan Sesuai keinginan Pengguna Berdasarkan I/O Yang Tersedia Didalam Kernel

* tanpa tweak build.prop apa pun, pilihan tergantung pada perangkat dan kernel Anda

* UNIVERSAL !!!

##### APLIKASI :

* Termux  ❌
* Terminal Emulator  ✅

##### Cara Setting :

* su (enter) xmod (enter)
* su -c xmod

#####
* Kemungkinan Tidak Bisa Digunakan Di Device Samsung.
* User Ginkgo & whyred Kemungkinan Tidak Dapat Menggunakan Fitur I/O Schedule

* Hanya kemungkinan 😁😁😁, silahkan tes dan laporkan

#

#### without any build.prop tweaks, the choice depends on your device and kernel

#### Semua Fitur X-MOD Module Magisk V6.2

* Merubah Governor Cpu Dan Gpu Sesuai Keinginan Pengguna Berdasarkan Kernel

* Disable Thermal :
```
   - Disable Thermal xtreme
   - Disable Thermal Normal
```

* Clean Cache ( include fs-trim )

* Close App 
```
   - Disable App ( Menggunakan List )
   - Close App ( Otomatis )
```

* Pilihan Zram:
```
   - 2 Gb
   - 3 Gb
   - 4 Gb
```
* Merubah Resolusi Layar Sesuai Keinginan Pengguna, Suport Ratio :
```
   - 16:9
   - 16.5:9
   - 19:9
   - 18:9
```
* Fitur Game
   - Memfokuskan Kinerja Android Untuk Aplikasi Game Yang Di Tentukan Sesuai Keinginan Pengguna 

* Fitur I/O Scheduler 
```
    I/O Schedul Untuk Meningkatkan Performa Yang         Lebih Baik Disaat Bermain Game.
    I/O Dapat Disesuaikan Sesuai keinginan Pengguna       Berdasarkan I/O Yang Tersedia Didalam Kernel
```
#####

* Silahkan Nikmati Module Magisk X-MOD Sesuai Kebutuhan 
 * Jika Perlu, Tambahkan Module Magisk Yang Mengandalkan Kode Kode  Tweaks build.prop
