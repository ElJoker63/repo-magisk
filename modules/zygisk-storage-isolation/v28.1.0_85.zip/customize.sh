SKIPUNZIP=1
CONFIG_PATH="/data/adb/storage-isolation"
FLAVOR=zygisk

#########################################################

# Extract verify.sh
ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort "*********************************************************"
fi
. $TMPDIR/verify.sh

# Extract util_functions.sh
ui_print "- Extracting util_functions.sh"
extract "$ZIPFILE" 'util_functions.sh' "$TMPDIR"
. $TMPDIR/util_functions.sh

#########################################################

enforce_install_from_magisk_app
check_magisk_version
check_android_version
check_arch

# Check app version
[ -f "$CONFIG_PATH/.server_version" ] && VERSION=$(cat "$CONFIG_PATH/.server_version") || VERSION=0
[ "$VERSION" -eq "$VERSION" ] || VERSION=0
ui_print "- Storage Isolation core service version: $VERSION"
if [ "$VERSION" -lt 333 ]; then
  ui_print "*****************************************"
  ui_print "! Storage Isolation app is not installed or the version is too low"
  ui_print "! Please upgrade the app to v8.0.0 or above and upgrade core service in the app"
  ui_print "! You can find download link from https://sr.rikka.app"
  abort "*****************************************"
fi

# Extract libs
ui_print "- Extracting module files"

extract "$ZIPFILE" 'module.prop' "$MODPATH"
extract "$ZIPFILE" 'post-fs-data.sh' "$MODPATH"
extract "$ZIPFILE" 'uninstall.sh' "$MODPATH"

if [ "$FLAVOR" == "zygisk" ]; then
  mkdir "$MODPATH/zygisk"

  extract "$ZIPFILE" "lib/$ARCH_NAME/libstorage-isolation.so" "$MODPATH/zygisk" true
  mv "$MODPATH/zygisk/libstorage-isolation.so" "$MODPATH/zygisk/$ARCH_NAME.so"

  if [ "$IS64BIT" = true ]; then
    extract "$ZIPFILE" "lib/$ARCH_NAME_SECONDARY/libstorage-isolation.so" "$MODPATH/zygisk" true
    mv "$MODPATH/zygisk/libstorage-isolation.so" "$MODPATH/zygisk/$ARCH_NAME_SECONDARY.so"
  fi
elif [ "$FLAVOR" == "riru" ]; then
  extract "$ZIPFILE" 'riru.sh' "$TMPDIR"
  . $TMPDIR/riru.sh

  mkdir "$MODPATH/riru"
  mkdir "$MODPATH/riru/lib"

  if [ "$IS64BIT" = true ]; then
    mkdir "$MODPATH/riru/lib64"
  fi

  extract "$ZIPFILE" "lib/$ARCH_NAME/lib$RIRU_MODULE_LIB_NAME.so" "$MODPATH/riru/$ARCH_DIR" true

  if [ "$IS64BIT" = true ]; then
    extract "$ZIPFILE" "lib/$ARCH_NAME_SECONDARY/lib$RIRU_MODULE_LIB_NAME.so" "$MODPATH/riru/$ARCH_DIR_SECONDARY" true
  fi
fi

if [ "$ARCH" = "arm" ] || [ "$ARCH" = "arm64" ]; then
  if [ "$IS64BIT" = true ]; then
    extract "$ZIPFILE" "lib/arm64-v8a/libstarter.so" "$MODPATH" true
  else
    extract "$ZIPFILE" "lib/armeabi-v7a/libstarter.so" "$MODPATH" true
  fi
elif [ "$ARCH" = "x86" ] || [ "$ARCH" = "x64" ]; then
  if [ "$IS64BIT" = true ]; then
    extract "$ZIPFILE" "lib/x86_64/libstarter.so" "$MODPATH" true
  else
    extract "$ZIPFILE" "lib/x86/libstarter.so" "$MODPATH" true
  fi
fi

mv "$MODPATH/libstarter.so" "$MODPATH/starter"

extract "$ZIPFILE" 'main.dex' "$MODPATH"

set_perm_recursive "$MODPATH" 0 0 0755 0644

if [ "$(grep_prop ro.maple.enable)" == "1" ] && [ "$FLAVOR" == "zygisk" ]; then
  ui_print "- Add ro.maple.enable=0"
  touch "$MODPATH/system.prop"
  echo "ro.maple.enable=0" >> "$MODPATH/system.prop"
fi
