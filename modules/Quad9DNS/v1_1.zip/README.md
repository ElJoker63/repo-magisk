# Quad9DNS4Magisk
Using Quad9 DNS through Magisk
