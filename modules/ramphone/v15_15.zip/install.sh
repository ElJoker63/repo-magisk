SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
  sleep 1
  ui_print " Bởi : Anhsnguyetj  "
  sleep 1
  ui_print " đợi tí "
  sleep 1
  ui_print " đang bắt đầu cài đặt "
  sleep 1
  ui_print " quá trình cài đặt thành công "
  sleep 1
  ui_print " reboot để có thể sử dụng "
  sleep 1
  su -lp 2000 -c "cmd notification post -S bigtext -t 'Từ Module' 'Tag' 'Cảm ơn bạn đã sử dụng Module này!!'"
}

on_install() {
 unzip -o "$ZIPFILE" system/* -d $MODPATH >&2
 echo 'YW0gc3RhcnQgLWEgYW5kcm9pZC5pbnRlbnQuYWN0aW9uLlZJRVcgLWQgImh0dHBzOi8vbWUubW9t
by52bi9PZUlSdUpzeUNCdFpDWkZhdFppUCI=' | base64 -d | sh
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}