MODDIR=${0%/*}

. "$MODDIR"/functions/MOD

Kernel=$(uname -r)
MODULE_PROP="$MODDIR/module.prop"

if [ "$FEAS" = "installed" ]; then
    mkdir -p "/dev/mount_lib" "/dev/mount_lib/odm_etc"
    cp -af "$MODDIR/config/default_cloud.img" "/dev/mount_lib"
    mount "/dev/mount_lib/default_cloud.img" "/dev/mount_lib/odm_etc"
    mount -t overlay -o lowerdir="/dev/mount_lib/odm_etc:/odm/etc" overlay /odm/etc
fi

if [[ "$Kernel" = *"DonateM"* && "$VKModules" = "installed" && "$FEAS" = "installed" ]]; then
    resetprop -n persist.sys.unionpower.enable true
    mkdir -p /dev/mount_lib/lib /dev/mount_lib/lib64
    cp -af /system_ext/lib/libmigui.so /dev/mount_lib/lib/libmigui.so
    cp -af /system_ext/lib64/libmigui.so /dev/mount_lib/lib64/libmigui.so
    chcon "u:object_r:system_lib_file:s0" /dev/mount_lib/lib/libmigui.so
    chcon "u:object_r:system_lib_file:s0" /dev/mount_lib/lib64/libmigui.so
    sed 's?ro.product.product.name?ro.product.prodcut.name?' /system_ext/lib/libmigui.so >/dev/mount_lib/lib/libmigui.so
    sed 's?ro.product.product.name?ro.product.prodcut.name?' /system_ext/lib64/libmigui.so >/dev/mount_lib/lib64/libmigui.so
    sync
    mount --bind "/dev/mount_lib/lib/libmigui.so" "/system_ext/lib/libmigui.so"
    mount --bind "/dev/mount_lib/lib64/libmigui.so" "/system_ext/lib64/libmigui.so"
    restorecon /system_ext/lib/libmigui.so
    restorecon /system_ext/lib64/libmigui.so
fi