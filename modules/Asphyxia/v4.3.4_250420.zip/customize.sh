# 设置权限
set_perm_recursive $MODPATH 0 0 0755 0644

MODDIR=${0%/*}

. "$MODPATH/utils.sh"

MOD="/data/adb/modules/Asphyxia"
VK_DIR="$MODPATH/vk"
VK_7475="$VK_DIR/SM7475"
JOY_Default="$MODPATH/config"
JOY_Cloud="$MODPATH/default_cloud"
QTIFEAS="$JOY_Cloud/qti/default_cloud.img"
UNFEAS="$JOY_Cloud/unicorn/default_cloud.img"
THFEAS="$JOY_Cloud/thor/default_cloud.img"
MODULE_PROP="$MODPATH/module.prop"
SYSTEM_PROP="$MODPATH/system.prop"
SERVICE_SH="$MODPATH/service.sh"
POST_FS_DATA_SH="$MODPATH/post-fs-data.sh"
FUNCTIONS="$MODPATH/functions"
PROP="$FUNCTIONS/prop"

soc_model=$(getprop ro.soc.model)
DEVICE=$(getprop ro.product.device)
Android_Version=$(getprop ro.build.version.release)
Kernel=$(uname -r)

Perf_etc="/system/vendor/etc/perf"
origin_file="$Perf_etc/perfconfigstore.xml"
overlay_file="$MODPATH$origin_file"

key_click() {
    while true; do
        sleep 0.5
        keyInfo=$(getevent -qlc 1 | grep KEY_VOLUME)
        if [ -n "$keyInfo" ]; then
            case "$keyInfo" in
                *KEY_VOLUMEUP*) return 0 ;;
                *) return 1 ;;
            esac
        fi
    done
}

if [[ "$KSU" == "true" ]]; then
    echo "- KernelSU 用户空间版本号: $KSU_VER_CODE"
    echo "- KernelSU 内核空间版本号: $KSU_KERNEL_VER_CODE"
    if [ "$KSU_KERNEL_VER_CODE" -lt 11089 ]; then
        echo "*********************************"
        echo "! 请安装 KernelSU 管理器 v0.6.2 或更高版本"
        abort "*********************************"
    fi
    RootImplement="KernelSU"
    version="$KSU_VER_CODE"
    versionCode="$KSU_KERNEL_VER_CODE"
elif [[ "$APATCH" == "true" ]]; then
    echo "- APatch 版本名: $APATCH_VER"
    echo "- APatch 版本号: $APATCH_VER_CODE"
    RootImplement="APatch"
    version="$APATCH_VER"
    versionCode="$APATCH_VER_CODE"
else
    echo "- Magisk 版本名: $MAGISK_VER"
    echo "- Magisk 版本号: $MAGISK_VER_CODE"
    RootImplement="Magisk"
    version="$MAGISK_VER"
    versionCode="$MAGISK_VER_CODE"
    if [ "$MAGISK_VER_CODE" -lt 26000 ]; then
        echo "*********************************"
        echo "! 请安装 Magisk 26.0+"
        abort "*********************************"
    fi
fi

zRAM() {
    { echo; cat "$PROP/Memory.prop"; } >> "$SYSTEM_PROP"
    
    echo "MemOpt=installed" >>"$FUNCTIONS/MOD"

    if [[ -f $origin_file && -s $origin_file ]]; then
        mkdir -p $(dirname $overlay_file)
        cp $origin_file $overlay_file

        update_overlay ro.vendor.perf.enable.prekill false
        update_overlay ro.lmk.kill_heaviest_task_dup false
        update_overlay ro.lmk.enhance_batch_kill false
        update_overlay ro.lmk.enable_watermark_check false
        update_overlay ro.lmk.enable_preferred_apps false
        
        update_overlay ro.lmk.super_critical 800

        update_overlay ro.lmk.direct_reclaim_pressure 55
        update_overlay ro.lmk.reclaim_scan_threshold 1024

        update_overlay ro.vendor.qti.sys.fw.bg_apps_limit 255

        update_overlay vendor.debug.enable.memperfd false

        update_overlay ro.lmk.nstrat_low_swap 1
        update_overlay ro.lmk.nstrat_psi_partial_ms 250
        update_overlay ro.lmk.nstrat_psi_complete_ms 700
        update_overlay ro.lmk.psi_scrit_complete_stall_ms 800
        update_overlay ro.lmk.nstrat_psi_scrit_complete_stall_ms 800
    fi
    
    sed -i "/description=/s/$/[Memory Optimize] /" "$MODULE_PROP"
}

off() {
    if [[ "$Kernel" == *"Pandora"* ]]; then
        abort "- 检测到 [Kernel-Pandora]❗"
    fi
    
    if [ -d "$MODDIR/VoyagerKernel-Additional-Module" ]; then
        abort "- 检测到 [VoyagerKernel-Additional-Module]❗"
    fi

    if [ -d "$MODDIR/Mi6X666" ]; then
        abort "- 检测到 [Game Booster]❗"
    fi

    if pidof uperf >/dev/null || [ -d "$MODDIR/uperf" ]; then
        abort "- 检测到 [uperf]❗"
    fi
    
    if [ -d "$MODDIR/scene_swap_controller" ]; then
        abort "- 检测到 [Scene附加模块(二)-3.6.5]❗"
    fi
    
    if [ -d "$MODDIR/MemoryOpt" ]; then
        abort "- 检测到 [MemoryOpt]❗"
    fi
    
    if [[ "$Kernel" != *"DonateM"* ]]; then
        if [[ "$DEVICE" != "diting" && "$DEVICE" != "unicorn" && "$DEVICE" != "mondrian" && "$DEVICE" != "thor" ]]; then
            abort "- 仅支持 <K50Ultra> <K60> <12SPro> <12SUltra> 用户❗"
        fi
    fi
    
    if [[ "$Kernel" == *"DonateM"* ]]; then
        if [ ! -d "/mi_ext" ] && [ ! -d "/dev/mi_display" ]; then
            abort "- 非小米机型，停止刷入❗"
        elif [ "$(getprop ro.board.platform)" != "taro" ]; then
            abort "- 检测到非目标soc <taro>❗"
        fi
    fi

    if [[ "$DEVICE" == "unicorn" ]] && [ -d "/sys/module/perfmgr" ]; then
        cp -f "$QTIFEAS" "$UNFEAS"
    elif [[ "$DEVICE" == "thor" ]] && [ -d "/sys/module/perfmgr" ]; then
        cp -f "$QTIFEAS" "$THFEAS"
    fi
    
    if [ "$soc_model" = "SM7475" ]; then
        cp -f "$VK_7475/perfmgr.ko" "$VK_DIR"
        rm -rf "$VK_7475"
    else
        rm -rf "$VK_7475"
    fi
    
    if [ "$soc_model" = "SM8450" ]; then
        rm -rf "$VK_DIR/kshrink_lruvecd.ko"
    fi
}

if [ -d "$MOD" ]; then
    MOD_PROP="$MOD/module.prop"
    if [ -f "$MOD_PROP" ]; then
        VERSION_CODE=$(awk -F= '/^versionCode[[:space:]]*=/ {print $2; exit}' "$MOD_PROP")
        if [ "$VERSION_CODE" -lt 250312 ]; then
            abort "- 检测到 旧版[定制优化] 的存在❗请卸载重启并阅读模块内使用说明后刷入"
        fi
    fi
fi

uninstall_old_module() {
    MODULE_ID="$(grep_prop id "$MODPATH/module.prop")"
    CUR_PWD="$PWD"
    cd "/data/adb/modules/$MODULE_ID" || return
    echo ""
    echo "-          Cleanup old module"
    PROPS="$(awk '/^persist\./ {sub(/=.*/, ""); print}' "/data/adb/modules/$MODULE_ID/system.prop")"
    sh "/data/adb/modules/$MODULE_ID/uninstall.sh" wait >/dev/null 2>&1
    for prop in $PROPS; do
        resetprop -p --delete "$prop"
    done
    cd "$CUR_PWD" || return
}

echo "*********************************"
echo "-       刷入前是否阅读 [更新日志/说明]"
echo "          音量↑:[是]│音量↓:[否]"

if key_click; then
    echo "              ✔"
    off
    rm -rf /data/system/package_cache
    uninstall_old_module
    
    echo "Android=$Android_Version" >>"$FUNCTIONS/MOD"
    echo "socid=$soc_model" >>"$FUNCTIONS/MOD"
else
    echo "请看完再刷"
    abort "                        ✔"
fi

if [[ "$Kernel" == *"DonateM"* ]]; then
    echo ""
    echo "[$Kernel]"
    echo "-      检测到当前内核为 [VoyagerKernel]"
    echo ""
    
    target_api="2412 2502 250201 2503"
    vk_abi_version=$(cat /sys/module/vendor_hooks/parameters/vk_abi_version)
    adapted_api=""
    for i in $target_api; do
        if [[ "$vk_abi_version" == "$i" ]]; then
            adapted_api="$vk_abi_version"
            break
        fi
    done

    if [[ -z "$adapted_api" ]]; then
      abort "- 你的内核不支持安装Voyager Kernel附加模块，请升级内核后重试❗"
    fi
    
    case "$DEVICE" in
    *"diting"*|*"mondrian"*)
        printf "\nro.product.prodcut.name=$DEVICE\n" >> "$SYSTEM_PROP"
        ;;
    *)
        printf "\nro.product.prodcut.name=diting\n" >> "$SYSTEM_PROP"
        ;;
    esac
    
    echo "VKModules=installed" >>"$FUNCTIONS/MOD"
    
    sed -i "/author=/s/$/| TheVoyager /" "$MODULE_PROP"
    
    cp -f "$QTIFEAS" "$UNFEAS"
    cp -f "$QTIFEAS" "$THFEAS"
    
    { echo; cat "$PROP/Sched.prop"; } >> "$SYSTEM_PROP"
    
    echo ""
    echo "-       是否添加 [内存管理优化-ZSTDN]"
    echo "          音量↑:[是]│音量↓:[否]"
    
    if key_click; then
        echo "              ✔"
        zRAM
        if [ "$soc_model" != "SM8450" ]; then
            sed -i "/description=/s/$/[VoyagerKernel Module 已安装: Perfmgr Fusion | VK Turbo Sched | ZSTDN | KSLRU]/" "$MODULE_PROP"
        else
            sed -i "/description=/s/$/[VoyagerKernel Module 已安装: Perfmgr Fusion | VK Turbo Sched | ZSTDN]/" "$MODULE_PROP"
        fi
    else
        echo "                        ✔"
        echo "MemOpt=cancelled" >>"$FUNCTIONS/MOD"
        sed -i "/description=/s/$/[VoyagerKernel Module 已安装: Perfmgr Fusion | VK Turbo Sched]/" "$MODULE_PROP"
    fi
else
    echo ""
    echo "-       是否添加 [内存管理优化-MemOpt]"
    echo "          音量↑:[是]│音量↓:[否]"
    
    if key_click; then
        echo "              ✔"
        zRAM
    else
        echo "                        ✔"
        echo "MemOpt=cancelled" >>"$FUNCTIONS/MOD"
    fi
    rm -rf "$VK_DIR"
    rm -rf "$MODPATH/action.sh"
fi


echo ""
echo "-          是否优化 [perfboost]"
echo "          音量↑:[是]│音量↓:[否]"

if key_click; then
    echo "              ✔"
else
    echo "                        ✔"
    rm -rf "$MODPATH/$Perf_etc/perfboostsconfig.xml"
    rm -rf "$MODPATH/$Perf_etc/perfboostselection.xml"
fi

echo ""
echo "-          是否优化 [dex2oat]"
echo "          音量↑:[是]│音量↓:[否]"

if key_click; then
    echo "              ✔"
    { echo; cat "$PROP/dex2oat.prop"; } >> "$SYSTEM_PROP"
else
    echo "                        ✔"
fi
echo "*********************************"

. "$FUNCTIONS/MOD"

if [[ "$MemOpt" = "installed" ]]; then
    Meminfo_KB=$(awk '/MemTotal/{print $2}' /proc/meminfo)
    Meminfo_GB=$(echo "scale=2; $Meminfo_KB / 1048576" | bc)
    
    if [ "$(echo "$Meminfo_GB > 16" | bc)" -eq 1 ]; then
        ZRAM_Size=36
    elif [ "$(echo "$Meminfo_GB > 12" | bc)" -eq 1 ]; then
        ZRAM_Size=24
    elif [ "$(echo "$Meminfo_GB > 8" | bc)" -eq 1 ]; then
        ZRAM_Size=16
    elif [ "$(echo "$Meminfo_GB > 6" | bc)" -eq 1 ]; then
        ZRAM_Size=10
    elif [ "$(echo "$Meminfo_GB > 4" | bc)" -eq 1 ]; then
        ZRAM_Size=8
    else
        ZRAM_Size=6
    fi
    
    echo "ZRAM_Size=$(echo "$ZRAM_Size * 1024 * 1024 * 1024" | bc)" >>"$FUNCTIONS/MOD"
fi

QTI_DEVICE=$DEVICE

if [ ! -d "$JOY_Cloud/$QTI_DEVICE" ]; then
    QTI_DEVICE="qti"
fi
    
mkdir "$JOY_Default"
cp -f "$JOY_Cloud/$QTI_DEVICE/default_cloud.img" "$JOY_Default"
rm -rf "$JOY_Cloud"

echo "- 正在还原Joyose"
pm clear com.xiaomi.joyose >/dev/null
pm clear com.miui.daemon >/dev/null
pm clear com.miui.powerkeeper >/dev/null
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver >/dev/null
am broadcast com.xiaomi.joyose/com.xiaomi.joyose.JoyoseBroadCastReceiver >/dev/null

echo "FEAS=installed" >>"$FUNCTIONS/MOD"

echo "- 正在清理doze白名单"
# doze
for item in `dumpsys deviceidle whitelist`
do
    app=`echo "$item" | cut -f2 -d ','`
    dumpsys deviceidle whitelist -$app >/dev/null
done

# doze whitelist
dumpsys deviceidle whitelist +com.xiaomi.xmsf >/dev/null
dumpsys deviceidle whitelist +com.tencent.mm >/dev/null
dumpsys deviceidle whitelist +com.omarea.vtools >/dev/null

echo "- 请立即重启以享用模块😇"
find "$MODPATH" -type d -empty -delete
echo "- 而浮生若梦，为欢几何？"