MODDIR=${0%/*}

. "$MODDIR/utils.sh"

SERVICE_SH="$MODDIR/service.sh"

key_click() {
    while true; do
        sleep 0.5
        keyInfo=$(getevent -qlc 1 | grep KEY_VOLUME)
        if [ -n "$keyInfo" ]; then
            case "$keyInfo" in
                *KEY_VOLUMEUP*) return 0 ;;
                *) return 1 ;;
            esac
        fi
    done
}

echo "-      是否修改调速器为tv移植的 [UAG]"
echo "          音量↑:[是]│音量↓:[否]"

if key_click; then
    echo "              ✔"
    set_governor uag
else
    echo "                        ✔"
    set_governor walt
fi