MODDIR=${0%/*}

. "$MODDIR/utils.sh"

Kernel=$(cat /proc/version | awk -F' ' '{print $3}')
KVersion=$(echo $Kernel | awk -F'.' '{print $1}')

sdk=`getprop ro.system.build.version.sdk`

MemTotalStr=`cat /proc/meminfo | grep MemTotal`
MemTotalKB=${MemTotalStr:16:8}

DEVICE=$(getprop ro.product.device)
VK_DIR="$MODDIR/vk"

MODULE_PROP="$MODDIR/module.prop"
MOD="$MODDIR/functions/MOD"

. "$MOD"

Check_Module() {
    lsmod | awk '{print $1}' | grep -qx "$1"
}

Clean_Write() {
    local key="$1"
    local file="$2"
    sed -i "/^${key}=/d" "$file"
    echo "${key}=installed" >> "$file"
}

optimize() {
    set_governor walt
    
    lock_val "2147483647" /sys/class/devfreq/*kgsl-3d0/max_freq
    lock_val "0" /sys/class/devfreq/*kgsl-3d0/min_freq
    kgsl="/sys/class/kgsl/kgsl-3d0"
    NUM_PWRLVL="$(cat $kgsl/num_pwrlevels)"
    MIN_PWRLVL="$((NUM_PWRLVL - 1))"
    lock_val "$MIN_PWRLVL" $kgsl/default_pwrlevel
    lock_val "$MIN_PWRLVL" $kgsl/min_pwrlevel
    lock_val "0" $kgsl/max_pwrlevel
    lock_val "0" $kgsl/thermal_pwrlevel
    lock_val "0" $kgsl/throttling
    lock_val "0" $kgsl/force_bus_on
    lock_val "0" $kgsl/force_clk_on
    lock_val "0" $kgsl/force_no_nap
    lock_val "0" $kgsl/force_rail_on
    lock_val "0" $kgsl/preemption
    lock_val "0" $kgsl/bcl
    lock_val "100" "$kgsl/devfreq/mod_percent"
    
    BUS_DIR="/sys/devices/system/cpu/bus_dcvs"
    lock_val_in_path "0" "$BUS_DIR" "min_freq"
    lock_val_in_path "0" "$BUS_DIR" "boost_freq"
    
    if [[ "$Kernel" = *"DonateM"* && "$VKModules" = "installed" ]]; then
        echo 1 > /sys/module/vendor_hooks/parameters/vk_boot_flag
        
        insmod "$VK_DIR"/perfmgr.ko
        if Check_Module "perfmgr"; then
            Clean_Write "Perfmgr" "$MOD"
            echo Y > /sys/module/perfmgr/parameters/freq_scaling
        fi
        
        insmod "$VK_DIR"/hyperframe.ko
        if Check_Module "hyperframe"; then
            Clean_Write "hyperframe" "$MOD"
        fi
        
        mask_val "0" /sys/module/migt/parameters/enable_pkg_monitor
        mask_val "0" /proc/sys/migt/enable_pkg_monitor
        mask_val "0" /sys/module/migt/parameters/glk_freq_limit_walt
        mask_val "0" /sys/module/metis/parameters/cluaff_control
    fi
    
    rmdir /dev/cpuset/foreground/boost /dev/cpuset/background/untrusted
    rm -rf /dev/memcg /dev/blkio

    LITTLE_LIST="$(cat /sys/devices/system/cpu/cpu0/topology/package_cpus_list)"
    ALL_LIST="$(cat /sys/devices/system/cpu/present)"
    lock_val "$LITTLE_LIST" /dev/cpuset/background/cpus
    lock_val "$ALL_LIST" /dev/cpuset/system-background/cpus
    lock_val "$ALL_LIST" /dev/cpuset/foreground/cpus
    lock_val "$ALL_LIST" /dev/cpuset/top-app/cpus
    lock_val "$LITTLE_LIST" /proc/irq/default_smp_affinity
    lock_val_in_path "$LITTLE_LIST" "/proc/irq" "smp_affinity_list"
    
    disable_corectl
    
    exec_system "settings put system miui_app_cache_optimization 0"
    exec_system "pm clear com.android.htmlviewer"
    exec_system "pm disable com.android.htmlviewer/com.android.settings.services.MemoryOptimizationService"
    exec_system "am broadcast com.android.htmlviewer/com.android.settings.cloud.CloudControlBootCompletedReceiver"
}

init_zram() {
    swapoff /dev/block/zram0
    
    if [[ "$Kernel" = *"DonateM"* && "$VKModules" = "installed" ]]; then
        rmmod zram
        insmod "$VK_DIR"/crypto_zstdn.ko
        insmod "$VK_DIR"/zram.ko
        
        if Check_Module "zram"; then
            Clean_Write "ZRAM" "$MOD"
        fi
        
        if Check_Module "crypto_zstdn"; then
            Clean_Write "ZSTDN" "$MOD"
        fi
        
        if [[ "$socid" != "SM8450" ]]; then
            insmod "$VK_DIR"/kshrink_lruvecd.ko
        fi
        
        if Check_Module "kshrink_lruvecd"; then
            Clean_Write "KSLRU" "$MOD"
        fi
    fi
    
    lock_val "1" /sys/class/block/zram0/reset
    lock_val "0" /sys/class/block/zram0/mem_limit
    lock_val "none" /sys/class/block/zram0/backing_dev
    
    case $Kernel in
        *ztc1997*)   Target="zstd";;
        *DonateM*)    Target="zstdn";;
        *ETO*)    Target="zstd";;
        *)           Target="lzo-rle";;
    esac
    lock_val "$Target" /sys/class/block/zram0/comp_algorithm
    lock_val "$ZRAM_Size" /sys/class/block/zram0/disksize
    
    mkswap /dev/block/zram0
    swapon /dev/block/zram0
}

VM="/proc/sys/vm"

set_vm_params() {
    echo "*************************"
    echo "设置watermark_scale_factor"
    mask_val "100" $VM/watermark_scale_factor
    
    echo "设置extra_free_kbytes"
    mask_val "131072" $VM/extra_free_kbytes
      
    echo "设置swappiness"
    mask_val "100" $VM/swappiness
    
    echo "设置min_free_kbytes"
    mask_val "32768" $VM/min_free_kbytes

    echo "设置cache"
    # 降低了读写缓存，对于目前的UFS3闪存来说，IO性能足够，并不需要太多内存缓存来提高性能
    mask_val "2" $VM/dirty_background_ratio
    mask_val "5" $VM/dirty_ratio
    mask_val "3000" $VM/dirty_expire_centisecs
    mask_val "5000" $VM/dirty_writeback_centisecs
    mask_val "150" $VM/vfs_cache_pressure
    
    echo "设置其它vm参数"
    mask_val "0" $VM/swap_ratio_enable
    mask_val "4" $VM/kswapd_threads
    mask_val "0" /sys/module/vmpressure/parameters/allocstall_threshold
    # 每次换入的内存页，3表示2的三次方，即8页
    #   每页的大小可以通过 `getcon PAGESIZE` 查看，一般是4KB
    case $Kernel in
        *ztc1997*)   comp="0";;
        *DonateM*)    comp="0";;
        *ETO*)    comp="0";;
        *)           comp="1";;
    esac
    mask_val "$comp" $VM/page-cluster
    # 杀死触发oom的那个进程
    mask_val "0" $VM/oom_kill_allocating_task
    # 是否打印 oom日志
    mask_val "0" $VM/oom_dump_tasks
    # 是否要允许压缩匿名页
    mask_val "1" $VM/compact_unevictable_allowed
    # 后台进行压缩的积极性(0~100)
    mask_val "20" $VM/compaction_proactiveness
    # vm 状态更新频率
    mask_val "1" $VM/stat_interval
    # CommitLimit=Swap+Zram+(RAM * overcommit_ratio / 100)
    mask_val "100" $VM/overcommit_ratio
    mask_val "1" $VM/overcommit_memory
    mask_val "0" $VM/panic_on_oom
}


set_lmk_params() {
    echo "*************************"
    echo "设置lmk参数"

    # Android Q+
    if [[ $sdk -gt 28 ]]; then
        minfree_levels=""
        # > 8G
        if [[ $MemTotalKB -gt 8388608 ]]; then
            minfree_levels="4096:0,5120:100,32768:200,96000:250,131072:900,204800:950"
        # > 6G
        elif [[ $MemTotalKB -gt 6291456 ]]; then
            minfree_levels="4096:0,5120:100,8192:200,32768:250,96000:900,131072:950"
        else
            minfree_levels="4096:0,5120:100,8192:200,32768:250,56320:900,71680:906"
        fi

        resetprop sys.lmk.minfree_levels "$minfree_levels"
        # Only for MIUI
        if [[ $KVersion -lt 5 ]] && [[ $(getprop ro.miui.ui.version.name) != '' ]]; then
            stop lmkd
            start lmkd
            resetprop sys.lmk.minfree_levels "$minfree_levels"
        fi
    fi
}

device_configs() {
    exec_system "device_config set_sync_disabled_for_tests until_reboot"
    exec_system "device_config put activity_manager max_cached_processes 65535"
    exec_system "device_config put activity_manager max_phantom_processes 65535"
    exec_system "device_config put lmkd_native use_minfree_levels false"
    exec_system "device_config delete lmkd_native thrashing_limit_critical"
    exec_system "device_config put activity_manager use_compaction false"
    exec_system "settings put global settings_enable_monitor_phantom_procs false"
}

wait_until_login

if [[ "$MemOpt" = "installed" && "$FEAS" = "installed" ]]; then
    setprop persist.miui.extm.bdsize 0
    sleep 15
    init_zram
    set_vm_params
    device_configs
    set_lmk_params
fi

if [[ "$FEAS" = "installed" ]]; then
    optimize
fi

VK_RMOD() {
    rmmod miwill_mode_redudancy
    rmmod miwill
    su -c lsmod > "$MODDIR"/functions/KM_Load.txt
}

. "$MOD"

if [[ "$socid" != "SM8450" ]] && 
   [[ "$MemOpt" = "installed" ]] && 
   [[ "$ZRAM" = "installed" ]] && 
   [[ "$ZSTDN" = "installed" ]] && 
   [[ "$KSLRU" = "installed" ]] && 
   [[ "$Perfmgr" = "installed" ]] && 
   [[ "$hyperframe" = "installed" ]]; then
    VK_RMOD
elif [[ "$socid" = "SM8450" ]] && 
   [[ "$MemOpt" = "installed" ]] && 
   [[ "$ZRAM" = "installed" ]] && 
   [[ "$ZSTDN" = "installed" ]] && 
   [[ "$Perfmgr" = "installed" ]] && 
   [[ "$hyperframe" = "installed" ]]; then
    VK_RMOD
elif [[ "$socid" = "SM8450" ]] && 
   [[ "$MemOpt" = "cancelled" ]] && 
   [[ "$Perfmgr" = "installed" ]] && 
   [[ "$hyperframe" = "installed" ]]; then
    VK_RMOD
else
    if [[ "$VKModules" = "installed" ]]; then
        sed -i "s/\[VoyagerKernel Module 已安装: Perfmgr Fusion | VK Turbo Sched | ZSTDN | KSLRU\]//" "$MODULE_PROP"
        sed -i "s/\[VoyagerKernel Module 已安装: Perfmgr Fusion | VK Turbo Sched | ZSTDN\]//" "$MODULE_PROP"
        sed -i "s/\[VoyagerKernel Module 已安装: Perfmgr Fusion | VK Turbo Sched\]//" "$MODULE_PROP"
        sed -i "s/\[VoyagerKernel Module 未安装\]//" "$MODULE_PROP"
        sed -i "/description=/s/$/[VoyagerKernel Module 未安装]/" "$MODULE_PROP"
        su -c lsmod > "$MODDIR"/functions/KM_DontLoad.txt
    fi
fi

if [[ "$FEAS" != "installed" || -z "$FEAS" ]]; then
    sed -i "s/\[Joyose Optimize\]//" "$MODULE_PROP"
    sed -i "s/\[Perf Optimize\]//" "$MODULE_PROP"
    sed -i "s/\[Memory Optimize\]//" "$MODULE_PROP"
    sed -i "s/\[模块运行错误：尝试重新安装\]//" "$MODULE_PROP"
    sed -i "/description=/s/$/[模块运行错误：尝试重新安装]/" "$MODULE_PROP"
fi

busybox=/data/adb/magisk/busybox
if [[ -f /data/adb/ksu/bin/busybox ]]; then
    busybox=/data/adb/ksu/bin/busybox
fi

if [[ -f $busybox ]]; then
    sm fstrim 2>/dev/null
    $busybox fstrim /data 2>/dev/null
    $busybox fstrim /cache 2>/dev/null
    $busybox fstrim /system 2>/dev/null
    sm fstrim 2>/dev/null
fi
    