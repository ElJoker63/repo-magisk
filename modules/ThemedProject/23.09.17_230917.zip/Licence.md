This is open source software, and by using it you agree to the following terms:

- You are free to review the code and use parts of it in your own projects.
- You may use pre-built packages (apks) for personal, non-commercial use such as custom ROMs.
- You are not allowed to re-share, reuse, or fork my code as your own, with or without changes. If you wish to make any changes, please create a commit and I will review it.
- If you wish to use this software for commercial or closed source projects, please contact me for further licensing.

Thank you for respecting these terms.