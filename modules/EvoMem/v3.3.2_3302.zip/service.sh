#!/system/bin/sh
EvoMem=${0%/*}
rm -rf /data/media/0/EvoMem.log
log() {
    log_file="/data/media/0/EvoMem.log"
    touch /data/media/0/EvoMem.log
    echo "[$(date | awk '{print $4}')] $@" >>"$log_file"
}
log "Module run:"
. $EvoMem/EvoMem