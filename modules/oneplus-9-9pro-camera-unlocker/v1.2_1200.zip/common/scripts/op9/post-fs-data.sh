#!/system/bin/sh
# This script will be executed in post-fs-data mode
TMPFILE="${0%/*}/overridden_at_boot_DO_NOT_EDIT"

if [[ -f "$TMPFILE" ]]; then rm "$TMPFILE"; fi
cp /odm/etc/camera/CameraHWConfiguration.config "$TMPFILE" || exit 1
sed -i -r 's/SystemCamera *= *[01]; *[01].*/SystemCamera = 0;  0;  0;  0;  1/g' "$TMPFILE" || exit 1
chcon u:object_r:vendor_configs_file:s0 "$TMPFILE" || exit 1
mount --bind "$TMPFILE" /odm/etc/camera/CameraHWConfiguration.config
