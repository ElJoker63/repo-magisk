##### Introduction: GameUnlocker | Magisk/KSU Module

##### Contact: [Akera](https://t.me/itzakera)

##### Support: Universal

#### Note: Unlock Game Graphics/FPS. This module will not work if You're using MagiskHide Props. Or others similar Modules with it. Not Work for All Games, causing SafetyNet fail. Need Xposed module to fix or bypass SafetyNet. It may break some system Apps, such as Miui Camera, Package Installer and etc.

##### ✓ INSTALLATION: Just flash via Magisk and reboot

##### Disclaimer: Naturally, you take all the responsibility for what happens to your device when you start messing around with things. I (Akira) will not be responsible for ANY damage caused to anyone's devices due to the use of this module.
