rm -fr "$(find /data/app -name *com.google.android.youtube*)"
rm -fr /data/data/com.google.android.youtube
rm -fr /data/local/tmp/apks
rm -rf /data/adb/vanced
rm -rf /data/adb/service.d/vanced.sh
rm -rf /data/adb/post-fs-data.d/vanced.sh
rm -rf /data/adb/revanced
rm -rf /data/adb/service.d/revanced.sh
rm -rf /data/adb/post-fs-data.d/revanced.sh