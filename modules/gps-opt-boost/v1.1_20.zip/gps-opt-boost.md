### GPS Boost&Opt v1.0 - 01.01.2023

* Improved GPS stability Fixed
  * Log OFF
  * Fix Server to Select
  * Emergency Location ON
  * Minor fixes
  * Fix Code
