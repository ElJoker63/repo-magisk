2.14  
• Improvements  
• Correction of current time in log-file  

2.13  
• Added support of some Xiaomi  
• Fixes  

2.12  
• Added support of  
~ Poco M5, Android 12 miui  
~ Realme 6pro, Android 12   
~ Tecno Camon 19 Neo, Android 12  

2.11  
• Initial release
