SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"
sleep 2
  ui_print " ———————————————————————————————— "
  ui_print "      Tsukasa E-sport 2.1     "
  ui_print " ———————————————————————————————— "
 sleep 2
  ui_print " Cek Device  "
sleep 3
  ui_print "- "
  ui_print "   "
  ui_print "      Device Info        : $(getprop ro.product.board) "
sleep 2
  ui_print "     Selinux Info         : $(getprop ro.boot.selinux) "
sleep 2
  ui_print "     Kernel Info           : $(uname -r) "
sleep 2
  ui_print "     Build Date Info       : $(getprop ro.system.build.date) "
slepp 2
  ui_print "        Android Version  : $(getprop ro.system.build.version.release_or_codename) "
sleep 2
  ui_print "     Rom Info            : $(getprop ro.build.flavor) "
sleep 2
  ui_print "    Description Rom Info : $(getprop ro.build.description) "
sleep 2
  ui_print "    Fingerprint Info     : $(getprop ro.build.fingerprint) "
  ui_print "   "
  ui_print "  "
  ui_print "- "
sleep 2
  ui_print " INSTALL MODULE "
sleep 2
ui_print "-----------[succsess]-------------- "
sleep 2
  ui_print "Joined to my channel for next update "
  ui_print " |||||||||||||||||||||||||||||||  "
  ui_print "  @ZxyonQiy | @ZxyonQiyChnnel  "