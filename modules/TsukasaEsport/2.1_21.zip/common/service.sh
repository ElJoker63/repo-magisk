#!/bin/sh
#klo mau ambil credit lah cok @ZxyonQiy

#function
write_code() {
  if [ -f "$1" ]; then
    if [ ! -w "$1" ]; then
      chmod +w "$1"
    fi
     echo "$2" > "$1"
	fi
}

while [ -z "$(resetprop sys.boot_completed)" ]; do
    sleep 5
done

#KernelPanic
write_code "/proc/sys/kernel/panic" "0" 
write_code "/proc/sys/kernel/panic_on_oops" "0"
write_code "/proc/sys/kernel/panic_on_rcu_stall" "0"
write_code "/proc/sys/kernel/panic_on_warn" "0"
write_code "/sys/module/kernel/parameters/panic" "0"
write_code "/sys/module/kernel/parameters/panic_on_warn" "0"
write_code "/sys/module/kernel/parameters/panic_on_oops" "0"

#kernelPrintk
write_code "/proc/sys/kernel/printk" "0 0 0 0"
write_code "/proc/sys/kernel/printk_devkmsg" "off"
write_code "/sys/module/printk/parameters/console_suspend" "Y"
write_code "/sys/module/printk/parameters/cpu" "N"
write_code "/sys/module/printk/parameters/ignore_loglevel" "Y"
write_code "/sys/module/printk/parameters/pid" "N"
write_code "/sys/module/printk/parameters/time" "N"
write_code "/sys/kernel/printk_mode/printk_mode" "0"

find /sys/ -name "*log*" -o -name "*debug*" | while IFS= read -r logdebug; do
wr
write_code "$logdebug" "0"
done

write_code "/proc/sys/kernel/sched_tunable_scaling" "1"

#dropCaches
write_code "/proc/sys/vm/drop_caches" "3"
write_code "/proc/sys/vm/dirty_background_ratio" "20"
write_code "/proc/sys/vm/dirty_expire_centisecs" "1000"
write_code "/proc/sys/vm/page-cluster" "0"
write_code "/proc/sys/vm/dirty_ratio" "10"
write_code "/proc/sys/vm/laptop_mode" "0"
write_code "/proc/sys/vm/block_dump" "1"
write_code "/proc/sys/vm/compact_memory" "0"
write_code "/proc/sys/vm/dirty_writeback_centisecs" "5000"
write_code "/proc/sys/vm/oom_dump_tasks" "1"
write_code "/proc/sys/vm/oom_kill_allocating_task" "0"
write_code "/proc/sys/vm/stat_interval" "60"
write_code "/proc/sys/vm/panic_on_oom" "0"
write_code "/proc/sys/vm/swappiness" "20"
write_code "/proc/sys/vm/vfs_cache_pressure" "50"
write_code "/proc/sys/vm/overcommit_ratio" "80"
write_code "/proc/sys/vm/extra_free_kbytes" "10240"
write_code "/proc/sys/kernel/random/read_wakeup_threshold" "64"
write_code "/proc/sys/kernel/random/write_wakeup_threshold" "128"

#lowMemoryKiller
write_code "/sys/module/lowmemorykiller/parameters/minfree" "5120,6144,7168,8192,9216,10240"

#cpuboost optimazation
write_code "/sys/module/cpu_boost/parameters/topkek_boost_freq" "0:0 4:0"
write_code "/sys/module/cpu_boost/parameters/topkek_boost_ms" "100"
write_code "/sys/module/cpu_boost/parameters/input_boost_freq" "0:0"
write_code "/sys/module/cpu_boost/parameters/input_boost_freq" "1:0"
write_code "/sys/module/cpu_boost/parameters/input_boost_freq" "2:0"
write_code "/sys/module/cpu_boost/parameters/input_boost_freq" "3:0"
write_code "/sys/module/cpu_boost/parameters/input_boost_freq" "4:0"
write_code "/sys/module/cpu_boost/parameters/input_boost_freq" "5:0"
write_code "/sys/module/cpu_boost/parameters/input_boost_freq" "6:0"
write_code "/sys/module/cpu_boost/parameters/input_boost_freq" "7:0"
write_code "/sys/module/cpu_boost/parameters/input_boost_ms" "100"

#gpuboost optimazation
write_code "/sys/module/gpu_boost/parameters/topkek_boost_freq" "0:0 4:0"
write_code "/sys/module/gpu_boost/parameters/topkek_boost_ms" "100"
write_code "/sys/module/gpu_boost/parameters/input_boost_freq" "0:0"
write_code "/sys/module/gpu_boost/parameters/input_boost_freq" "1:0"
write_code "/sys/module/gpu_boost/parameters/input_boost_freq" "2:0"
write_code "/sys/module/gpu_boost/parameters/input_boost_freq" "3:0"
write_code "/sys/module/gpu_boost/parameters/input_boost_freq" "4:0"
write_code "/sys/module/gpu_boost/parameters/input_boost_freq" "5:0"
write_code "/sys/module/gpu_boost/parameters/input_boost_freq" "6:0"
write_code "/sys/module/gpu_boost/parameters/input_boost_freq" "7:0"
write_code "/sys/module/gpu_boost/parameters/input_boost_ms" "100"


#schedI/O optimazation
for queue in /sys/block/mmcblk*/queue; do
write_code "$queue/scheduler" "none"
write_code "$queue/add_random" "0"
write_code "$queue/iostats" "0"
write_code "$queue/read_ahead_kb" "256"
write_code "$queue/nr_requests" "128"

write_code "/sys/kernel/debug/sched_features" "NO_GENTLE_FAIR_SLEEPERS:1"
write_code "/sys/kernel/debug/sched_features" "START_DEBIT:1"
write_code "/sys/kernel/debug/sched_features" "NEXT_BUDDY:1"
write_code "/sys/kernel/debug/sched_features" "LAST_BUDDY:1"
write_code "/sys/kernel/debug/sched_features" "STRICT_SKIP_BUDDY:1"
write_code "/sys/kernel/debug/sched_features" "CACHE_HOT_BUDDY:1"
write_code "/sys/kernel/debug/sched_features" "WAKEUP_PREEMPTION:1"
write_code "/sys/kernel/debug/sched_features" "NO_HRTICK:1"
write_code "/sys/kernel/debug/sched_features" "NO_DOUBLE_TICK:1"
write_code "/sys/kernel/debug/sched_features" "LB_BIAS:1"
write_code "/sys/kernel/debug sched_features" "NONTASK_CAPACITY:1"
write_code "/sys/kernel/debug/sched_features" "NO_TTWU_QUEUE:1"
write_code "/sys/kernel/debug/sched_features" "NO_SIS_AVG_CPU:1"
write_code "/sys/kernel/debug/sched_features" "RT_PUSH_IPI:1"
write_code "/sys/kernel/debug/sched_features" "NO_FORCE_SD_OVERLAP:1"
write_code "/sys/kernel/debug/sched_features" "NO_RT_RUNTIME_SHARE:1"
write_code "/sys/kernel/debug/sched_features" "NO_LB_MIN:1"
write_code "/sys/kernel/debug/sched_features" "ATTACH_AGE_LOAD:1"
write_code "/sys/kernel/debug/sched_features" "ENERGY_AWARE:1"
write_code "/sys/kernel/debug/sched_features" "NO_MIN_CAPACITY_CAPPING:1"
write_code "/sys/kernel/debug/sched_features" "NO_FBT_STRICT_ORDER:1"
write_code "/sys/kernel/debug/sched_features" "EAS_USE_NEED_IDLE:1"

#gpu min and max clock
write_code "$GPUDIR/gpu_min_clock" "$max_clock_gpu"
write_code "$GPUDIR/gpu_max_clock" "$max_clock_gpu"

#KGSLDIR min and max clock
write_code "$KGSLDIR/kgsl-3d0/min_clock_mhz" "$max_clock_kgsl"
write_code "$KGSLDIR/kgsl-3d0/max_clock_mhz" "$max_clock_kgsl"

write_code "$KGSLDIR/kgsl-3d0/throttling" "0"

#max cpufreq
write_code "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"
write_code "/sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq"
write_code "/sys/devices/system/cpu/cpu2/cpufreq/cpuinfo_max_freq"
write_code "/sys/devices/system/cpu/cpu3/cpufreq/cpuinfo_max_freq"
write_code "/sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq"
write_code "/sys/devices/system/cpu/cpu5/cpufreq/cpuinfo_max_freq"
write_code "/sys/devices/system/cpu/cpu6/cpufreq/cpuinfo_max_freq"
write_code "/sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq"

#cpu capacity optimazation
write_code "/sys/devices/system/cpu/cpu0/cpu_capacity"
write_code "/sys/devices/system/cpu/cpu1/cpu_capacity"
write_code "/sys/devices/system/cpu/cpu2/cpu_capacity"
write_code "/sys/devices/system/cpu/cpu3/cpu_capacity"
write_code "/sys/devices/system/cpu/cpu4/cpu_capacity"
write_code "/sys/devices/system/cpu/cpu5/cpu_capacity"
write_code "/sys/devices/system/cpu/cpu6/cpu_capacity"
write_code "/sys/devices/system/cpu/cpu7/cpu_capacity"

#cpu package
write_code "/sys/devices/system/cpu/cpu0/topology/physical_package_id"
write_code "/sys/devices/system/cpu/cpu1/topology/physical_package_id"
write_code "/sys/devices/system/cpu/cpu2/topology/physical_package_id"
write_code "/sys/devices/system/cpu/cpu3/topology/physical_package_id"
write_code "/sys/devices/system/cpu/cpu4/topology/physical_package_id"
write_code "/sys/devices/system/cpu/cpu5/topology/physical_package_id"
write_code "/sys/devices/system/cpu/cpu6/topology/physical_package_id"
write_code "/sys/devices/system/cpu/cpu7/topology/physical_package_id"

#core_cpu
write_code "/sys/devices/system/cpu/cpu0/core_ctl/enable" "1"
write_code "/sys/devices/system/cpu/cpu1/core_ctl/enable" "1"
write_code "/sys/devices/system/cpu/cpu2/core_ctl/enable" "1"
write_code "/sys/devices/system/cpu/cpu3/core_ctl/enable" "1"
write_code "/sys/devices/system/cpu/cpu4/core_ctl/enable" "1"
write_code "/sys/devices/system/cpu/cpu5/core_ctl/enable" "1"
write_code "/sys/devices/system/cpu/cpu6/core_ctl/enable" "1"
write_code "/sys/devices/system/cpu/cpu7/core_ctl/enable" "1"

#cpufreq top-app scaling
write_code "/sys/devices/system/cpu/cpu0/cpufreq/top-app/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpu1/cpufreq/top-app/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpu2/cpufreq/top-app/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpu3/cpufreq/top-app/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpu4/cpufreq/top-app/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpu5/cpufreq/top-app/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpu6/cpufreq/top-app/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpu7/cpufreq/top-app/scaling_governor" "performance"

#cpufreq policy scaling
write_code "/sys/devices/system/cpu/cpufreq/policy0/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpufreq/policy1/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpufreq/policy2/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpufreq/policy3/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpufreq/policy4/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpufreq/policy5/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpufreq/policy6/scaling_governor" "performance"
write_code "/sys/devices/system/cpu/cpufreq/policy7/scaling_governor" "performance"

#cpufrq delay skip to top-app
write_code "/sys/devices/system/cpu/cpufreq/performance/top-app/above_hispeed_delay" "0"

#cpufreq all cpu perf boost
write_code "/sys/devices/system/cpu/cpufreq/performance/boost" "1"

#responsiv cpufreq hispeed
write_code "/sys/devices/system/cpu/cpufreq/performance/go_hispeed_load" "75"

#cpufreq all cpu hysteresis max
write_code "/sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis" "1"

#windows up to perf
write_code "/sys/devices/system/cpu/cpufreq/performance/align_windows" "1"

#gpu grafis
write_code "/sys/class/drm/card0/device/power_dpm_force__max_performance_level" "1"
write_code "/sys/class/drm/card1/device/power_dpm_force__max_performance_level" "1"
write_code "/sys/class/drm/card2/device/power_dpm_force__max_performance_level" "1"
write_code "/sys/class/drm/card3/device/power_dpm_force__max_performance_level" "1"
write_code "/sys/class/drm/card4/device/power_dpm_force__max_performance_level" "1"
write_code "/sys/class/drm/card5/device/power_dpm_force__max_performance_level" "1"
write_code "/sys/class/drm/card6/device/power_dpm_force__max_performance_level" "1"
write_code "/sys/class/drm/card7/device/power_dpm_force__max_performance_level" "1"

#control cpu kernel
write_code "/sys/module/lazyplug/parameters/nr_possible_cores" "8"

#foreground cpu optimazation
write_code "/dev/cpuset/foreground/boost/cpus" "0-3"
write_code "/dev/cpuset/foreground/cpus" "4-7"
write_code "/dev/cpuset/top-app/cpus" "0-7"

#fs-trim
fstrim -v /metadata
fstrim -v /odm
fstrim -v /system_ext
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /preload

write_code "/sys/module/rpm_smd/parameters/debug_mask" "0"
write_code "/sys/module/msm_show_resume_irq/parameters/debug_mask" "0"
write_code "/sys/module/rmnet_data/parameters/rmnet_data_log_level" "0"
write_code "/sys/module/ip6_tunnel/parameters/log_ecn_error" "N"
write_code "/proc/sys/kernel/sched_schedstats" "0"
write_code "/sys/kernel/tracing/tracing_on" "0"
write_code "/sys/module/mmc_core/parameters/use_spi_crc" "0"

exit 0