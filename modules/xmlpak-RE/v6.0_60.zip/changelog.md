**6.0
- Fixed Google Dailer Call Rec

**5.5
- Fixed module not working for A13
- Unified Xmls

**5.0
- Fixed Google Spoof
- Updated Samsung, Sony
- Updated Module Installer

**4.5**    
- Fixed some Asus things
- Added more features 
- Fixed update loop

4.2: 
- Fixed GMS crash
- Fixed UWB crash
- Added DELL features
- Added HTC features
- Added some misc features for Alexa etc. 

4.1: fix of features that cause crash in some apps

4.0: updated Google, Motorola, Sony, OPPO/OnePlus xmls and added new Microsoft xml

3.6: add self-made Pixel 4 feature xml

3.5: replace Pixel 3a xmls to original

3.4: update the template

3.3: add self-made Pixel 3a feature xml

3.2: update main Samsung xml

3.1: possibly added ARCore apps support

3.0: add Razer Phone 2 xml

2.9: add Pixel 3 goodies

2.8: readded BQ Camera support

2.7: few xmls updated, what else?

2.6: initial version for repo
