# **xmlpak-RE – a road to vendor apps**

## What is RE ???
REincarnated or Maybe REvived ?? Or Something Else :P

## Description
This module enables you to download and install vendor apps from Google Play. Their compatibility is not guaranteed.

What vendors are supported?

HTC, OnePlus, Essential, Asus, Nokia/HMD Global, Nothing, Google , Motorola, BlackBerry, Nextbit, BQ, Sony, Samsung, Cyanogen, Razer, NVIDIA, Acer, Microsoft.

## Requirements
- Magisk
- KernelSU

## Instructions
**First installation of the module will result in Play Store data reset.** If you disabled automtic app updates, keep this in mind.

After reboot, wait. Or not. Play Store often isn't too hasty in terms of compatibility detection. If you want to be quicker and don't want to say something about not working module, Turn on Airplane Mode , reset Play Store and Play Store Services data + reboot again. And if you are somehow on Marshmallow, you may even need to wipe the whole data.

## Credits
Based on [Original](https://github.com/Magisk-Modules-Repo/xmlpak) xmlpak module.
