#!/system/bin/sh
MODDIR=${0%/*}
# Deshabilitar estadísticas de E/S de disco
if [ "$(ls /sys/block | grep sda)" = "sda" ]; then
    echo 0 >/sys/block/sda/queue/iostats
    echo 0 >/sys/block/sde/queue/iostats
fi

# Deshabilitar la depuración y el registro del kernel
echo 0 >/sys/module/binder/parameters/debug_mask
echo 0 >/sys/module/binder_alloc/parameters/debug_mask

# Ajustar el número de páginas de memoria virtual
echo 0 >/proc/sys/vm/page-cluster

# Ajuste el intervalo de estadísticas de la memoria virtual (el valor predeterminado es 1, que es 1 segundo)
echo 20 >/proc/sys/vm/stat_interval
