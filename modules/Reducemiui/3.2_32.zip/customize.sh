#!/bin/bash
SKIPUNZIP=0

# Deshabilite el registro de miui, si necesita tomar el registro, ¡no lo habilite!
is_clean_logs=true
# ¡Desactive los servicios de depuración no esenciales!
is_reduce_test_services=true
# Use hosts para bloquear algunos nombres de dominio de anuncios de Xiaomi
# Nota: el uso de esta función causará problemas al cargar imágenes en línea en la tienda de temas
is_use_hosts=false
# Modo de compilación de optimización dex2oat predeterminado
dex2oat_mode="everything"
# Obtener el SDK del sistema
SDK="$(getprop ro.system.build.version.sdk)"

if [[ $KSU == true ]]; then
  ui_print "- KernelSU El número de versión actual del espacio de usuario: $KSU_VER_CODE"
  ui_print "- KernelSU El número de versión actual del espacio del kernel.: $KSU_KERNEL_VER_CODE"
else
  ui_print "- Versión Magisk: $MAGISK_VER_CODE"
  if [ "$MAGISK_VER_CODE" -lt 26000 ]; then
    ui_print "*********************************************"
    ui_print "! Por favor instalar Magisk 26.0+"
    abort "*********************************************"
  fi
fi

rm -rf /data/system/package_cache

# Obtener información sobre las aplicaciones instaladas
echo "$(pm list packages -f -a)" >$MODPATH/packages.log
sed -i -e 's/\ /\\\n/g' -e 's/\\//g' -e 's/package://g' $MODPATH/packages.log

# ReduceMIUI directorio de archivos de configuración personalizados
mkdir -p /storage/emulated/0/Android/ReduceMIUI
[ ! -f /storage/emulated/0/Android/ReduceMIUI/DeshabilitarApps.prop ] && cp ${MODPATH}/DeshabilitarApps.prop /storage/emulated/0/Android/ReduceMIUI
[ ! -f /storage/emulated/0/Android/ReduceMIUI/dex2oat.prop ] && cp ${MODPATH}/dex2oat.prop /storage/emulated/0/Android/ReduceMIUI
Package_Name_Reduction="$(cat /storage/emulated/0/Android/ReduceMIUI/DeshabilitarApps.prop | grep -v '#')"
dex2oat_list="$(cat /storage/emulated/0/Android/ReduceMIUI/dex2oat.prop | grep -v '#')"
if [[ ! -f /storage/emulated/0/Android/ReduceMIUI/history.prop ]]; then
  touch /storage/emulated/0/Android/ReduceMIUI/history.prop
else
  sort -u /storage/emulated/0/Android/ReduceMIUI/history.prop >/storage/emulated/0/Android/ReduceMIUI/history_new.prop
  rm -rf /storage/emulated/0/Android/ReduceMIUI/history.prop
  mv /storage/emulated/0/Android/ReduceMIUI/history_new.prop /storage/emulated/0/Android/ReduceMIUI/history.prop
  history_list="$(cat /storage/emulated/0/Android/ReduceMIUI/history.prop)"
fi

if [[ $KSU == true ]]; then
  touch_replace() {
    if [[ "$1" != system ]]; then
      if [[ "$1" == odm ]]; then
        mkdir -p "$MODPATH"/system/vendor"$2"
        rm -rf "$MODPATH"/system/vendor"$2"
        mknod "$MODPATH"/system/vendor"$2" c 0 0
      else
        mkdir -p "$MODPATH"/system"$2"
        rm -rf "$MODPATH"/system"$2"
        mknod "$MODPATH"/system"$2" c 0 0
      fi
    else
      mkdir -p "$MODPATH""$2"
      rm -rf "$MODPATH""$2"
      mknod "$MODPATH""$2" c 0 0
    fi
    echo "$2" >>/storage/emulated/0/Android/ReduceMIUI/history.prop
  }
else
  touch_replace() {
    if [[ "$1" != system ]]; then
      if [[ "$1" == odm ]]; then
        mkdir -p "$MODPATH"/system/vendor"$2"
        touch "$MODPATH"/system/vendor"$2"/.replace
        chown root:root "$MODPATH"/system/vendor"$2"/.replace
        chmod 0644 "$MODPATH"/system/vendor"$2"/.replace
      else
        mkdir -p "$MODPATH"/system"$2"
        touch "$MODPATH"/system"$2"/.replace
        chown root:root "$MODPATH"/system"$2"/.replace
        chmod 0644 "$MODPATH"/system"$2"/.replace
      fi
    else
      mkdir -p "$MODPATH""$2"
      touch "$MODPATH""$2"/.replace
      chown root:root "$MODPATH""$2"/.replace
      chmod 0644 "$MODPATH""$2"/.replace
    fi
    echo "$2" >>/storage/emulated/0/Android/ReduceMIUI/history.prop

  }
fi

reduce_test_services() {
  if [ "$is_reduce_test_services" == "true" ]; then
    if [ "$SDK" -le 30 ]; then
      ui_print "- se está deteniendo ipacm-diag"
      stop ipacm-diag
      echo "stop ipacm-diag" >>$MODPATH/service.sh
    fi
    if [ "$SDK" -ge 31 ]; then
      ui_print "- se está deteniendo ipacm-diag"
      stop vendor.ipacm-diag
      echo "stop vendor.ipacm-diag" >>$MODPATH/service.sh
    fi
  fi
  if [ "$is_clean_logs" == "true" ]; then
    if [ "$SDK" -le 30 ]; then
      ui_print "- se está deteniendo tcpdump"
      stop tcpdump
      echo "stop tcpdump" >>$MODPATH/service.sh
      ui_print "- se está deteniendo cnss_diag"
      stop cnss_diag
      echo "stop cnss_diag" >>$MODPATH/service.sh
    elif [ "$SDK" -ge 31 ]; then
      ui_print "- se está deteniendo tcpdump"
      stop vendor.tcpdump
      echo "stop vendor.tcpdump" >>$MODPATH/service.sh
      ui_print "- se está deteniendo cnss_diag"
      stop vendor.cnss_diag
      echo "stop vendor.cnss_diag" >>$MODPATH/service.sh
      ui_print "- se está deteniendo logd"
      stop logd
      echo "stop logd" >>$MODPATH/service.sh
    fi
    ui_print "- Borrando MIUI WiFi log"
    rm -rf /data/vendor/wlan_logs/*
    echo "rm -rf /data/vendor/wlan_logs/*" >>$MODPATH/service.sh
    ui_print "- Borrando MIUI 充电 log"
    rm -rf /data/vendor/charge_logger/*
    echo "rm -rf /data/vendor/charge_logger/*" >>$MODPATH/service.sh
  fi
}

uninstall_useless_app() {
  ui_print "- El servicio inteligente se está deshabilitando"
  if [ "$(pm list package | grep 'com.miui.systemAdSolution')" != "" ]; then
    pm disable com.miui.systemAdSolution >/dev/null
    echo "pm disable com.miui.systemAdSolution" >>$MODPATH/service.sh
    ui_print "- Servicios inteligentes deshabilitados con éxito"
  else
    ui_print "- Los servicios inteligentes no existen o se han reducido"
  fi
  ui_print "- Se está eliminando Analytics"
  if [ "$(pm list package | grep 'com.miui.analytics')" != "" ]; then
    rm -rf /data/user/0/com.xiaomi.market/app_analytics/*
    chown -R root:root /data/user/0/com.xiaomi.market/app_analytics/
    chmod -R 000 /data/user/0/com.xiaomi.market/app_analytics/
    pm uninstall --user 0 com.miui.analytics >/dev/null
    echo "pm uninstall --user 0 com.miui.analytics >/dev/null" >>$MODPATH/service.sh
    if [ -d "/data/user/999/com.xiaomi.market/app_analytics/" ]; then
      rm -rf /data/user/999/com.xiaomi.market/app_analytics/*
      chown -R root:root /data/user/999/com.xiaomi.market/app_analytics/
      chmod -R 000 /data/user/999/com.xiaomi.market/app_analytics/
      pm uninstall --user 999 com.miui.analytics >/dev/null
    fi
    ui_print "- Analytics eliminado con éxito"
  else
    ui_print "- Analytics no existe"
  fi
}

dex2oat_app() {
  ui_print "- Para garantizar la suavidad, ejecute dex2oat ($dex2oat_mode) la optimización lleva un tiempo..."
  for app_list in ${dex2oat_list}; do
    var=$app_list
    record="$(eval cat $MODPATH/packages.log | grep "$var"$)"
    apk_path="${record%=*}"
    apk_dir="${apk_path%/*}"
    apk_name="${apk_path##*/}"
    apk_name="${apk_name%.*}"
    apk_source="$(echo $apk_dir | cut -d"/" -f2)"
    if [[ "$(unzip -l $apk_path | grep lib/)" == "" ]] || [[ "$(unzip -l $apk_path | grep lib/arm64)" != "" ]]; then
      apk_abi=arm64
    else
      apk_abi=arm
    fi
    if [ -n "$apk_source" ]; then
      if [[ "$apk_source" == "data" ]]; then
        if [ "$(unzip -l $apk_path | grep classes.dex)" != "" ]; then
          rm -rf "$apk_dir"/oat/$apk_abi/*
          dex2oat --dex-file="$apk_path" --compiler-filter=$dex2oat_mode --instruction-set=$apk_abi --oat-file="$apk_dir"/oat/$apk_abi/base.odex
          ui_print "- ${app_list}: 成功"
        fi
      else
        if [ "$(unzip -l $apk_path | grep classes.dex)" != "" ]; then
          if [[ "$apk_source" != system ]]; then
            if [[ "$apk_source" == odm ]]; then
              target_path=$MODPATH/system/vendor$apk_dir/oat/$apk_abi
            else
              target_path=$MODPATH/system$apk_dir/oat/$apk_abi
            fi
          else
            target_path="$MODPATH""$apk_dir"/oat/$apk_abi
          fi
          mkdir -p "$target_path"
          dex2oat --dex-file="$apk_path" --compiler-filter=$dex2oat_mode --instruction-set=$apk_abi --oat-file="$target_path"/"$apk_name".odex
          ui_print "- ${app_list}: Éxito"
        fi
      fi
    else
      ui_print "- ${app_list}: No existe"
    fi
  done
  ui_print "- Optimización completada"
}

package_replace() {
  for app_list in ${Package_Name_Reduction}; do
    var=$app_list
    record="$(eval cat $MODPATH/packages.log | grep "$var"$)"
    apk_path="${record%=*}"
    apk_dir="${apk_path%/*}"
    apk_source="$(echo $apk_dir | cut -d"/" -f2)"
    if [ -n "$apk_source" ]; then
      if [[ "$apk_source" == "data" ]]; then
        ui_print "- ${app_list} es una aplicación instalada manualmente o se ha reducido"
      else
        ui_print "- Deshabilitando ${app_list}"
        touch_replace "$apk_source" "$apk_dir"
      fi
    fi
  done
  for history in ${history_list}; do
    if [ -n "$history" ]; then
      history_source="$(echo $history | cut -d"/" -f2)"
      ui_print "- Deshabilitando ${history##*/}"
      touch_replace "$history_source" "$history"
    fi
  done
}

hosts_file() {
  # hosts
  if [[ $is_use_hosts == true ]]; then
    find_hosts="$(find /data/adb/modules*/*/system/etc -name 'hosts')"
    if [ "$(echo "$find_hosts" | grep -v "Reducemiui")" != "" ]; then
      echo "$find_hosts" | grep "Reducemiui" | xargs rm -rf
      find_hosts="$(find /data/adb/modules*/*/system/etc -name 'hosts')"
      have_an_effect_hosts="$(echo $find_hosts | awk '{print $NF}')"
      if [ "$(cat "${have_an_effect_hosts}" | grep '# Start Reducemiui hosts')" == "" ]; then
        cat "${MODPATH}/hosts.txt" >>${have_an_effect_hosts}
      fi
    else
      mkdir -p ${MODPATH}/system/etc/
      find_hosts="$(find /data/adb/modules*/Reducemiui/system/etc -name 'hosts')"
      if [ ! -f "${find_hosts}" ]; then
        cp -r /system/etc/hosts ${MODPATH}/system/etc/
        cat ${MODPATH}/hosts.txt >>${MODPATH}/system/etc/hosts
      else
        cp -r ${find_hosts} ${MODPATH}/system/etc/
      fi
    fi
  else
    ui_print "- el archivo de hosts no está habilitado"
  fi
}

remove_files() {
  rm -rf $MODPATH/hosts.txt
  rm -rf $MODPATH/DeshabilitarApps.prop
  rm -rf $MODPATH/dex2oat.prop
  rm -rf $MODPATH/packages.log
}

reduce_test_services
uninstall_useless_app
dex2oat_app
package_replace
hosts_file
remove_files
