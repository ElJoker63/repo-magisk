#!/system/bin/sh
MODDIR=${0%/*}
ln -sf $MODDIR/toolkit $MODDIR/system/bin