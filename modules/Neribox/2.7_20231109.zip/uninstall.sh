if [ -d /data/adb/Neribox ];then
    rm -rf /data/adb/Neribox
fi