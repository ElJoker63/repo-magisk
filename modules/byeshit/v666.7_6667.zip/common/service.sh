#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 60

####################################
# Services
####################################
su -c "stop logcat logcatd logd tcpdump cnss_diag statsd traced idd-logreader idd-logreadermain stats dumpstate aplogd"

####################################
# Useless Services 
####################################
su -c "pm disable com.google.android.gms/.chimera.GmsIntentOperationService"
su -c "pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver"

####################################
# System Log
####################################
su -c "pm uninstall --user 0 com.android.traceur"

####################################
# Kernel Debugging (thx to KTSR)
####################################
for i in 'debug_mask' 'log_level*' 'debug_level*' '*debug_mode' 'edac_mc_log*' 'enable_event_log' '*log_level*' '*log_ue*' '*log_ce*' 'log_ecn_error' 'snapshot_crashdumper' 'seclog*' 'compat-log' '*log_enabled' 'tracing_on' 'mballoc_debug'; do
    for o in $(find /sys/ -type f -name "$i"); do
        echo '0' > "$o"
    done
done

####################################
# CRC
####################################
for parameters in /sys/module/mmc_core/parameters/*; do
    echo '0' > "$parameters/removable"
    echo '0' > "$parameters/crc"
done

####################################
# Printk (thx to KNTD-reborn)
####################################
echo '0' > "/sys/module/printk/parameters/cpu"
echo '1' > "/sys/module/printk/parameters/console_suspend"
echo '0' > "/sys/kernel/printk_mode/printk_mode"
echo '1' > "/sys/module/printk/parameters/ignore_loglevel"
echo '0' > "/sys/module/printk/parameters/pid"
echo '0' > "/sys/module/printk/parameters/time"
echo '0' > "/sys/module/printk/parameters/printk_ratelimit"

####################################
# Ramdumps
####################################
for parameters in /sys/module/subsystem_restart/parameters; do
    echo '0' > "$parameters/enable_ramdumps"
    echo '0' > "$parameters/enable_mini_ramdumps"
done

####################################
# Virtual Memory
####################################
for virtual_memory in /proc/sys/vm; do
    echo '0' > "$virtual_memory/page-cluster"
    echo '0' > "$virtual_memory/panic_on_oom"
done

####################################
# File System
####################################
for fs in /proc/sys/fs; do
    echo '0' > "$fs/dir-notify-enable"
    echo '0' > "$fs/by-name/userdata/iostat_enable"
done

####################################
# Touchboost
####################################
echo '0' > "/sys/module/msm_performance/parameters/touchboost"

exit 0