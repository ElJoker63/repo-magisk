#!/system/bin/sh
MODDIR=${0%/*}

# XtremeSensivity, settings for touch.
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 60

# TouchBoostOff
write /sys/module/msm_performance/parameters/touchboost 0
write /sys/power/pnpmgr/touch_boost 0

exit 0