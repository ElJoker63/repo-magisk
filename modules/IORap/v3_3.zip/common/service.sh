#!/system/bin/sh
MODDIR=${0%/*}

su -c start iorapd

start iorap.cmd.compiler

exit