MODDIR=${0%/*}

# $1:value $2:path
lock_val() {
    [ ! -f "$2" ] && return
    umount "$2"

    chown 0:0  "$2"
    chmod 0644 "$2"
    echo "$1" >"$2"
    chmod 0444 "$2"

    echo "$1"  > /dev/asopt_mask
    mount --bind /dev/asopt_mask "$2"
    rm /dev/asopt_mask
}

fuck_core_ctls() {
    lock_val "0" /sys/module/mtk_core_ctl/parameters/policy_enable
    lock_val "0" /sys/module/mtk_fpsgo/parameters/boost_affinity
    lock_val "0" /sys/module/fbt_cpu/parameters/boost_affinity
    lock_val "0" /sys/kernel/fpsgo/minitop/enable

    for i in /sys/devices/system/cpu/cpu*/core_ctl/enable; do
        lock_val "0" $i
    done
}

until [ -d "/sdcard/Android" ]; do
    sleep 1
done

fuck_core_ctls
killall -15 AsoulOpt
nohup $MODDIR/AsoulOpt > /dev/null 2>&1 &
