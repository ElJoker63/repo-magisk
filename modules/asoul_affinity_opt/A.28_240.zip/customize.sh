CFG_PATH="/sdcard/Android/naki/asopt/asopt.conf"

echo "
- 卸载CuToolbox，你不卸载我帮你
- 配置位于 $CFG_PATH
- 可通过配置文件切换放置方案

- Uninstall CuToolbox, otherwise I will help you
- The config is at $CFG_PATH
- You can switch affinity plans in the config file
"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/AsoulOpt 0 0 0755

note="# fallback：放置方案
# 0：抢占优化方案，理论上表现更好
# 1：均衡负载方案，更接近官方调度
# 建议自行测试以选择更好的方案
# ***切换方案后重启生效***

# fallback: Affinity plans
# 0: Preemptive, performs better in theory
# 1: Load balancing, closer to the default
# Test by yourself to know which is better
# ***Reboot after switching to take effect***

"

fallback=$(grep fallback= $CFG_PATH)
if [ -z $fallback ]; then
    fallback="fallback=0"
fi

rm -rf /data/adb/modules/unity_affinity_opt /data/adb/asopt /sdcard/Android/asopt /data/asopt.conf /sdcard/Android/naki/asopt/asopt.log
mkdir -p /sdcard/Android/naki/asopt
echo "$note$fallback" > $CFG_PATH
