CFG_PATH="/sdcard/Android/naki/asopt/asopt.conf"

echo
echo "- 安装此模块前卸载CuToolbox，你不卸载我帮你卸载"
echo "- 配置文件位于 $CFG_PATH"
echo "- 可在配置文件内切换放置方案"
echo

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/AsoulOpt 0 0 0755

note="# fallback：放置方案
# 0：抢占优化方案，理论上表现更好
# 1：均衡负载方案，更接近官方调度
# 建议自行测试以选择更好的方案
# 人与人的体质是不同的，不建议套用别人的方案
# ***切换方案后重启生效***
"

fallback=$(grep fallback= $CFG_PATH)
if [ -z $fallback ]; then
    fallback="fallback=0"
fi

rm -rf /data/adb/modules/unity_affinity_opt /data/adb/asopt /sdcard/Android/asopt /data/asopt.conf /sdcard/Android/naki/asopt/asopt.log
mkdir -p /sdcard/Android/naki/asopt
echo "$note" > $CFG_PATH
echo "$fallback" >> $CFG_PATH
