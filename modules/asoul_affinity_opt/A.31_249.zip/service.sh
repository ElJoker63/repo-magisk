MODDIR=${0%/*}

# $1:value $2:path
lock_val() {
    [ ! -f "$2" ] && return
    umount "$2"

    chown 0:0  "$2"
    chmod 0644 "$2"
    echo "$1" >"$2"
    chmod 0444 "$2"

    echo "$1"  > /dev/asopt_mask
    mount --bind /dev/asopt_mask "$2"
    rm /dev/asopt_mask
}

fuck_boosts() {
    lock_val "0" /sys/module/mtk_fpsgo/parameters/boost_affinity
    lock_val "0" /sys/module/fbt_cpu/parameters/boost_affinity
    lock_val "0" /sys/kernel/fpsgo/minitop/enable
    lock_val "0" /proc/sys/walt/sched_boost
}

while [ -z `getprop sys.boot_completed` ]; do sleep 1; done
fuck_boosts
killall -15 AsoulOpt
nohup $MODDIR/AsoulOpt > /dev/null 2>&1 &
