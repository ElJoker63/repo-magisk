For support this project: [Patreon](https://avalibeyaz.com/patreon)  
--------------

## v1.1.1
- Removed "Magisk-Module" from part of project name due starting to support KernelSU too  
- Changed repo and module name from various files
  
## v1.1.0  
- Changed updateJson in module.prop for future updates  
- Modified zipUrl in update.json
- Removed unnecessary files
- Modified module description
- Modified README.md descriptions
- Fixed some typos in CHANGELOG.md
- Added Patreon welcome to CHANGELOG.md  
  
## v1.0.7  
- Added KernelSU support  
  
## v1.0.6  
- Minor improvments
  
## v1.0.5  
- Added create&release workflow  
    
## v1.0.4  
- Fixed Wifi issues, attempt 2  
  
## v1.0.3  
- Fixed Wifi issues  
  
## v1.0.2  
- Fixed updater  
  
## v1.0.1  
- Added "update.json" for self update feature  
- Added "changelog.md"  
- Switched to the new versioning system  
  
## v1.00  
- Initial release
