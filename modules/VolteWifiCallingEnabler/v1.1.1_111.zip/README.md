# VOLTE & WIFI Calling Enabler Magisk and KernelSU Module  

Should work all Android versions and UI's.
  
### FEATURES:  
- Enables Volte  
- Enables Wifi Calling (VoWiFi)  

### [DOWNLOAD](https://github.com/symbuzzer/Volte-Wifi-Calling-Enabler-Magisk-Module/releases/latest/download/Volte-Wifi-Calling-Enabler-Magisk-Module.zip)  
### [CHANGELOG](https://github.com/symbuzzer/Volte-Wifi-Calling-Enabler-Magisk-Module/blob/main/CHANGELOG.md)
