# None Display Cutout

This module provide you an option for hide the black notch bar.

Tested on Redmi Note 10 Pro, andriod 13.

### Usage

Settings -> Developer Options -> Cutout Emulation -> Notch bar killer

