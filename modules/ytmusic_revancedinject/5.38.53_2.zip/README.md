## YouTube Music ReVanced

YouTube Music ReVanced package by HuskyDG

### Background

- Dynamic mount YouTube ReVanced APK and make bind mount only be visible for YouTube App to avoid detection, other app will only see the original `base.apk` of YouTube.
- Dynamic patch Play Store everytime opening app to ensure YouTube is always detached
