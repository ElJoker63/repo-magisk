# Changelog

## v1.0.0 - 2022/8/14

- Stable release

## v0.2.0 - 2022/8/14

- Support update

## v0.1.0 - 2022/8/14

- Initial release
