# Magisk Show Camera Sounds Module

## Descriptions

This module shows 'Camera sounds' config on Google Camera: some phones, such as shipped from Japan hidden the config.

## Installation

Install through the Magisk app -> Modules -> Install from storage.
