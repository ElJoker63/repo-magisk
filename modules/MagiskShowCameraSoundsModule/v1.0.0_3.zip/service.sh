#!/sbin/sh
# Refet to https://topjohnwu.github.io/Magisk/guides.html#shell-scripts-sh

setprop audio.camerasound.force false
