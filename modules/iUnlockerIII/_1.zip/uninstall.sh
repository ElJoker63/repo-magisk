#!/system/bin/sh
rm -rf /data/adb/iunlocker-ram-expansion
rm -rf /dev/ram-expansion-iunlocker
rm -rf /dev/ram_expansion