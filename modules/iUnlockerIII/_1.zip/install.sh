# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false
# Put true if you need system.prop
PROPFILE=true
# Put true if you need post-fs-data.sh
POSTFSDATA=true
# Put true if you need service.sh
LATESTARTSERVICE=true
# Only Works with iUnlocker if you have the Ram expansion key put this to true
IUNLOCKER_RAMEXPANSION=true
. "$TMPDIR/function"

iScreen "
sys.iunlocker.cleaner=true" >> $magisk_sp
unzip -o "$ZIPFILE" 'system/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'RamExpansion/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'iSaddons/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'binkit/*' -d $TMPDIR >&2
. $TMPDIR/addon/Volume-Key-Selector/install.sh
  if [ "$abi" == "arm64-v8a" ]; then
IF64; SWITCH=true
  elif [ "$abi" == "x86" ]; then
IF32; SWITCH=true
  elif [ "$abi" == "armeabi-v7a" ]; then
  IF32; SWITCH=true
  elif [ "$abi" == "x86_64" ]; then
IF64; SWITCH=true
  elif [ "$abi" == "arm" ]; then
IF32; SWITCH=true
  elif [ "$abi" == "arm64" ]; then
IF64; SWITCH=true
  elif [ "$abi" == "x64" ]; then
IF64; SWITCH=true
else
iScreen " Abi not Verified abortion..."
exit 0
  fi
# Clean up binkit
if [[ "$SWITCH" == true ]]; then
CLEAR $TMPDIR/binkit
fi
if [ -e /data/adb/modules/iUnlocker-PUBG-NewState ]; then
Remove_dir /data/adb/modules/iUnlocker-PUBG-NewState
Remove_dir /data/adb/modules_update/iUnlocker-PUBG-NewState
elif [ -e /data/adb/modules_update/iUnlocker-PUBG-NewState ]; then
Remove_dir /data/adb/modules_update/iUnlocker-PUBG-NewState
wtf="wtf"
fi

# PUBG MOBILE SUPPORTED VERSIONS
IN | CH | TW | VIT | GB | KR

Ad="/data/adb/modules_update/iUnlockerIII/iSaddons"
Kits="/data/adb/modules_update/iUnlocker-Addons-kit"


if [ ! "$SDM" != "Qualcomm" ]; then
iScreen "iUnlocker.put.SDM8GEN1.chip=true" >> $magisk_sp
else
iScreen "[×] Your Processor not snapdragon 
[+] Disabling SDM 8 Gen 1 Processor ... "; indeed
iScreen "iUnlocker.put.SDM8GEN1.chip=false" >> $magisk_sp
fi  
AVRGSPACE="32GB*"
if [ -e /system/lib/libGLESv2.so ]; then
libGLESv2="68a39b24"
iScreen "sys.iunlocker.remode=$libGLESv2" >> $magisk_sp
else
iScreen "sys.iunlocker.dump=$libGLESv2" >> $magisk_sp
fi
change "$TMPDIR/iUnlocker"
SCState_game() {
if [ -e $Superclone ]; then
iScreen "iUnlockerList2.SuperClone.120fps=true" >> $magisk_sp
Tstate_game=$SCState1
else
Tstate_game=$SCState2
iScreen " - $Game_14 $SCState2! Skipping list 2"
  #6
  fi
  }
 #
DeadBydaylightDBDState_game() {
if [ -e $Deadbydaylight ]; then
iScreen "iUnlockerL2G5=$dbd_game_state" >> $magisk_sp
Tstate_game=$DBDState1
else
iScreen " - $Game_15 $DBDState2! Skipping list 2"
Tstate_game=$DBDState2
fi
}
 # LifeAfter
     LifeAfterState_game() {
     if [ -e $Lifeafter ]; then
     iScreen "iUnlockerList2.LifeAfter.120fps=true" >> $magisk_sp
     Tstate_game="$LifeState1"
       else
       iScreen " - $Game_12 $LifeState2! Skipping list 2"
       Tstate_game="$LifeState2"
       fi
}
     #
     # Cyber Hunter lo(w)
     CyberHunterLOW() {
     if [ -e $Cyberhunter ]; then
         iScreen "iUnlockerList2.CyberHunter.low=true" >> $magisk_sp 
         Tstate_game="$CHState1"
         else
         iScreen " - $Game_13 $CHState2! Skipping list 2"
         Tstate_game="$CHState2"
         fi
}
     #
     # Cyber hunter Hig(h)
     CyberHunterHIGH() {
     if [ -e $Cyberhunter ]; then
     iScreen "iUnlockerList2.CyberHunter.High=true" >> $magisk_sp
Tstate_game="$CHState1"
         else
         iScreen " - $Game_13 $CHState2! Skipping list 2"
         Tstate_game="$CHState2"
         fi
}
 #
 # Minecraft PE
MINECRAFT_PE() {
       if [ -e $MinecraftPE ]; then
       iScreen "binary.iunlocker.List2.MinecraftPE=true" >> $magisk_sp
       Tstate_game="$MCPEState1"
       else
         iScreen " - $Game_16 $MCPEState1! Skipping list 2"
         Tstate_game="$MCPEState2"
         fi
}
#
#### Start
#
#
#
## Other modules RM code!
MODULE1='unlock-it'
MODULE2='unlocker'
MODULE3='unlock*'
# Print'em
iScreen "! - Modules will be removed if you have them" >> $iLog
iScreen "$MODULE1" >> $iLog
iScreen "$MODULE2" >> $iLog
iScreen "$MODULE3" >> $iLog
iScreen "! - **********************" >> $iLog
iScreen 'remove_over_modules=true' >> $magisk_sp

# - # - # - # - # - # Loading List 1
iScreen ""
iScreen "!***************************************!"
Game_print "(1) [- ❌ Skip list 1]"
iScreen ""
Game_print "(2) [BGMI | PUBG & Mobile Legend & Lol Wild Rift] #90fps"
iScreen ""
Game_print "(3) [PUBG & Fortnite] #90fps"
iScreen ""
Game_print "(4) [League of Legends WildRift] #120fps"
iScreen ""
Game_print "(5) [Call Of Duty Mobile] #120fps"
iScreen ""
Game_print "(6) [Sky Children of light] #60fps"
iScreen ""
Game_print "(7) [Cyber Hunter] #90fps"
iScreen ""
Game_print "(8) [(Asphalt 9 60fps) + (Sky 60fps) + (PUBG All versions 90fps) ]"
iScreen ""
iScreen "!***************************************!"
L1=1
    while true; do
	              ui_print "#Number: $L1"
	 if $VKSEL; then
		        L1=$((L1 + 1))
	       else 
break
	     fi
	 if [ $L1 -gt 8 ]; then
       L1=1
	       fi
           done
case $L1 in
  #1
1) iUnlocker="| Skip list 1";;
2) iUnlocker="| $Game_1 + $Game_8 + $Game_6 | $iiifps_rate, $supported_versions"; iScreen "iUnlocker.PUBG.MlLegend.LolWilDRift=true" >> $magisk_sp;;
  #2
3) iUnlocker="| $Game_1 + $Game_7 | $iiifps_rate, $supported_versions"; iScreen "iUnlocker.fortnite.pubg=true" >> $magisk_sp;;
  #3
4) iUnlocker="| $Game_6 | $iiiifps_rate"; iScreen "iUnlocker.lolwildrift.120fps=true" >> $magisk_sp;;
  #4
5) iUnlocker="| $Game_5 | $iiiifps_rate"; iScreen "iUnlocker.CODM.120fps=true" >> $magisk_sp;;
  #5
6) iUnlocker="| $Game_4 + $Game_11 | $iifps_rate"; iScreen "iUnlocker.asphalt.skyChildren.60fps=true" >> $magisk_sp;;
  #6
7) iUnlocker="| $Game_10 | $iiifps_rate"; iScreen "iUnlocker.CyberHunter.90fps=true" >> $magisk_sp;;
8) iUnlocker="| $Game_4 + $Game_11 | $iifps_rate"; iScreen "iUnlocker.sky.asphalt.60fps=true" >> $magisk_sp;;
esac
iScreen ""
iLogs "
💵 - [ LIST 1 ]:
🎚️ You Select : $iUnlocker
🎚️ Game VSTF: 0.1Alpha
🎚️ AuthorName: $iAuth

"
iScreen ""
iLogs "*************************"
iScreen "!***************************************!"
Game_print "(1) [ Skip × list 2] "
iScreen ""
Game_print "(2) [ Life After ] #120fps"
iScreen ""
Game_print "(3) [ Cyber Hunter ] #Low Graphics"
iScreen ""
Game_print "(4) [ Cyber Hunter ] #High Graphics"
iScreen ""
Game_print "(5) [ Super Clone ] #120fps"
iScreen ""
iScreen "!***************************************!"

iScreen ""

L2=1
    while true; do
	              ui_print "#Number: $L2"
	 if $VKSEL; then
		        L2=$((L2 + 1))
	       else 
break
	     fi
	 if [ $L2 -gt 6 ]; then
       L2=1
	       fi
           done
case $L2 in
1) List2iUnlocker="| $non_game "; iScreen "iUnlocker.skip=true" >> $magisk_sp; BuiltIN="No type found! cuz you skipped the list"; Tstate_game="No Game found";;
  #2 
2) List2iUnlocker="| $Game_12 | $iiiifps_rate"; LifeAfterState_game; BuiltIN="$Graphics_type3";;
  #3
3) List2iUnlocker="| $Game_13 + $iGraphics_type"; CyberHunterLOW; BuiltIN="$Graphics_type1";;
  #4
4) List2iUnlocker="| $Game_13 | $iiGraphics_type"; CyberHunterHIGH; BuiltIN="$Graphics_type1";;
  #5
5) List2iUnlocker="| $Game_14 | $iiiifps_rate"; SCState_game; BuiltIN="$Graphics_type3";;
6) List2iUnlocker="| $Game_15 | $iiiifps_rate"; DeadBydaylightDBDState_game; BuiltIN="$Graphics_type3";;
7) List2iUnlocker="| $Game_16"; MINECRAFT_PE; BuiltIN="$Graphics_type2, $Graphics_type4";;
esac


iLogs "

💵 [ LIST 2 ]:
🎚️ You Select : $List2iUnlocker
🎚️ Game state: $Tstate_game
🎚️ Game VSTF: 6.0
🎚️ UnlockType: $BuiltIN
🎚️ AuthorName: $iAuth

 "
iScreen ""
iScreen ""
iScreen "  |/\| - Ram Expansion [Enabled] Select Ram:"
iScreen ""
iScreen " (1) - 3GB+ [+ Including iUnlocker Hex ] "
iScreen ""
iScreen " (2) - 4GB+ [+ Including iUnlocker Hex ] "
iScreen ""
iScreen " (3) - 6GB+ [Recommended] "
iScreen ""
iScreen " (4) - 8GB+ [ Only For 128GB ram devices ] "
iScreen ""
iScreen " (5) - 12GB+ [ Only For 256GB ram devices ] "
iScreen ""
iScreen " (6) - 16GB+ [ Only For 512GB ram devices ] "
iScreen ""
iScreen " (7) - 16GB+ [ All Devices ] "
iScreen ""
iScreen " (8) - ❌ Skip Ram Expansion feature"
iScreen ""
RAM_EXPANSION=1
    while true; do
iScreen ""
	              ui_print "🏷️Number: $RAM_EXPANSION"
	 if $VKSEL; then
		        RAM_EXPANSION=$((RAM_EXPANSION + 1))
	       else 
break
	     fi
	 if [ $RAM_EXPANSION -gt 8 ]; then
       RAM_EXPANSION=1
	       fi
           done
case $RAM_EXPANSION in
1) iOPTION="3GB"; iScreen "sys.binary.iunlocker.ram.expansion=3GB" >> $magisk_sp;;
2) iOPTION="4GB"; iScreen "sys.binary.iunlocker.ram.expansion=4GB" >> $magisk_sp;;
3) iOPTION="6GB"; iScreen "sys.binary.iunlocker.ram.expansion=6GB" >> $magisk_sp;;
4) iOPTION="8GB"; iScreen "sys.binary.iunlocker.ram.expansion=8GB" >> $magisk_sp;;
5) iOPTION="12GB"; iScreen "sys.binary.iunlocker.ram.expansion=12GB" >> $magisk_sp;;
6) iOPTION="16GB"; iScreen "sys.binary.iunlocker.ram.expansion=16GB" >> $magisk_sp;;
7) iOPTION="16GBAll"; iScreen "sys.binary.iunlocker.ram.expansion=16GBAll" >> $magisk_sp;;
8) iOPTION="Skip"; iScreen "sys.binary.iunlocker.ram.expansion=false" >> $magisk_sp;;
esac
iScreen ""
iScreen "You choose(d) - $iOPTION - for RAM EXPANSION"
iLogs "
🎚️RAM EXPANSION State: - $iOPTION
 "
 iScreen "!***************************************!"


Remove_dir $TMPDIR/function
  chmod 777 $TMPDIR/iUnlocker
  chmod 777 $TMPDIR/RamExpansion/*
  chmod 777 $TMPDIR/system/bin/*
  chmod 777 $TMPDIR/system/lib*/*
