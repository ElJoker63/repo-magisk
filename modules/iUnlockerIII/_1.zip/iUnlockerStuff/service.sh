#!/system/bin/sh
MODDIR=${0%/*}
.$MODDIR/iUnlocker
su -c $MODDIR/iUnlockerHex
su -c $MODDIR/system/bin/libiunlocker