#!/system/bin/sh
MODDIR=${0%/*}
.$MODDIR/iUnlocker
#su -c $MODDIR/iUnlockerHex


iUPATH="/data/adb/modules/iUnlockerIII"
ln -fs $iUPATH/system/lib/libuuid.so.1.0.0 $iUPATH/system/lib/libuuid.so
ln -fs $iUPATH/system/lib/libuuid.so.1.0.0 $iUPATH/system/lib/libuuid.so.1