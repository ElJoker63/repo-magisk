SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

REPLACE="
"

ui_print ""
ui_print "__________________________"
ui_print ""
ui_print "    SMOOTH GUI ANDROID    "
ui_print "__________________________"
ui_print " Smooth GUI Android "
ui_print " Dev : HenVx "
ui_print " Versi : 3.1  "
ui_print ""
ui_print ""
ui_print ""
ui_print ""
ui_print " Date : 23-8-2023 Build "