# This script will be executed in post-fs-data mode
# More info in the main Magisk thread
