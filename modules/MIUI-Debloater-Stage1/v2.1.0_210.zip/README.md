# MIUI Debloater Stage 1  
 Removes these non-removable apps from system without breaking anything:  
> - /system/app/AnalyticsCore - com.miui.analytics - "Analytics"  
> - /system/app/facebook-appmanager - com.facebook.appmanager "Facebook App Manager"  
> - /system/app/Joyose - com.xiaomi.joyose - "Joyose"  
> - /system/app/MiuiDaemon - com.miui.daemon - "MIUI Daemon"  
> - /system/app/MSA-Global - com.miui.msa.global "MSA Global"  
> - /system/app/MIUIMiPicks - com.xiaomi.mipicks - "GetApps"  
> - /system/app/PaymentService - com.xiaomi.payment - "Mi Coin"  
> - /system/app/XiaomiSimActivateService - com.xiaomi.simactivate.service - "Xiaomi SIM Activation Service"  
> - /system/app/InMipay - com.mipay.wallet.in - "Mi Pay"  
> - /system/priv-app/facebook-installer - com.facebook.system - "Facebook Installer"  
> - /system/priv-app/facebook-services - com.facebook.services - "Facebook Services"  
> - /system/priv-app/MIUIGlobalMinusScreen - com.mi.android.globalminusscreen - "Xiaomi App Vault"  
> - /system/priv-app/MIUIYellowPageGlobal - com.miui.yellowpage - "Yellow Page"  
> - /system/product/app/GoogleOne - com.google.android.apps.subscriptions.red - "Google One"  
> - /system/vendor/app/MipayService - com.mipay.android.manager - "MiPay Service"  
> - /system/vendor/app/SoterService - com.tencent.soter.soterserver - "Soter Service"  
> - /system/vendor/app/IFAAService - org.ifaa.aidl.manager - "IFAA Service"  
   
# [Downloads](https://github.com/symbuzzer/MIUI-Debloater-Magisk-Modules/releases)
