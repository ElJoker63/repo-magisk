rm -rf /data/adb/overlay
rm -rf /data/adb/overlay.xz