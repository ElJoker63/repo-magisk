## Registro de cambios:

-1.1
	Corregido error en version code.
	
-1.0
	Versión Inicial.
	
---

*ENGLISH VERSION*

---

## Changelog:

-1.1
	Fixed bug in code version.

-1.0
  	Initial version.
