# adb root

Enable adb root in production build device for Android 11+.

## Usage

Install it as a Magisk module

> :warning: **USE AT YOUR OWN RISK!!!**

## Build

```sh
./build.sh
```

## Credits

1. [adb_root](https://github.com/wuxianlin/adb_root)
2. [magisk enable adb root](https://liwugang.github.io/2021/07/11/magisk_enable_adbr_root.html)
