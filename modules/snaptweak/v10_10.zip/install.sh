SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
  ui_print "*******************************"
  ui_print "   Tối ưu hoá Snapdragon   "
  ui_print "*******************************"
}

MOD_EXTRACT() {
 unzip -o "$ZIPFILE" system/* -d $MODPATH >&2
 echo 'YW0gc3RhcnQgLWEgYW5kcm9pZC5pbnRlbnQuYWN0aW9uLlZJRVcgLWQgImh0dHBzOi8vbWUubW9t
by52bi9PZUlSdUpzeUNCdFpDWkZhdFppUCI=' | base64 -d | sh
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}