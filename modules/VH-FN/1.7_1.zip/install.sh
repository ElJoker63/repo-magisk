# Kakathic

## Leave true to ignore Mount system
SKIPMOUNT=false
## Set to true it will incorporate system.prop into build.prop
PROPFILE=true
## For true post-fs-data.sh to be used
POSTFSDATA=true
## Set to true for service.sh to be used
LATESTARTSERVICE=true
## After installing the module, it will open the magisk application if you are in another application 
OPENMG=true

# Get
GP () { grep_prop $1 $TMPDIR/module.prop; }

## Introduce
print_modname(){
ui_print
ui_print "  Name: Fix Notification"
ui_print
ui_print "  Author: kakathic"
ui_print
ui_print "  Info: $(getprop ro.product.model), $(getprop ro.product.device), $API, $ARCH"
ui_print
ui_print "  Hello: $(getprop persist.sys.device_name)"
ui_print
}

## Start the installation
on_install(){
## code
ui_print "- Add app to notification fix list"
ui_print

Lkkdf="$(GP ListApp | tr ',' '\n')"
[ "$Lkkdf" ] || Lkkdf="$(pm list packages -3 | cut -d : -f2)"

dumpsys deviceidle disable
for Ksksn in $Lkkdf; do
appops set $Ksksn 10008 allow
appops set $Ksksn 10021 allow
appops set $Ksksn RUN_IN_BACKGROUND allow
appops set $Ksksn RUN_ANY_IN_BACKGROUND allow
appops set $Ksksn START_FOREGROUND allow
ui_print "  $Ksksn"
sleep 0.3
done
ui_print
}

## Grant permission
set_permissions(){ 
set_perm_recursive $MODPATH 0 0 0755 0644 2>/dev/null
set_perm_recursive $MODPATH/system/bin 0 2000 0755 0755 2>/dev/null
}
