SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
  ui_print "*******************************"
  ui_print "   Tối ưu hoá Snapdragon   "
  ui_print "*******************************"
  
sleep 3

# Latch android
if [[ $(getprop ro.build.version.sdk) -le "32" ]]; then
  sed -i '/debug.sf.latch_unsignaled/s/.*/debug.sf.latch_unsignaled=0/' $MODPATH/system.prop
  sed -i '/debug.sf.auto_latch_unsignaled/s/.*/debug.sf.auto_latch_unsignaled=1/' $MODPATH/system.prop
fi
if [[ $(getprop ro.build.version.sdk) -ge "33" ]]; then
  sed -i '/debug.sf.latch_unsignaled/s/.*/debug.sf.latch_unsignaled=false/' $MODPATH/system.prop
  sed -i '/debug.sf.auto_latch_unsignaled/s/.*/debug.sf.auto_latch_unsignaled=true/' $MODPATH/system.prop
fi
}

MOD_EXTRACT() {
 unzip -o "$ZIPFILE" system/* -d $MODPATH >&2
 echo 'YW0gc3RhcnQgLWEgYW5kcm9pZC5pbnRlbnQuYWN0aW9uLlZJRVcgLWQgImh0dHBzOi8vbWUubW9t
by52bi9PZUlSdUpzeUNCdFpDWkZhdFppUCI=' | base64 -d | sh
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}