#!/system/bin/sh
MODDIR=${0%/*}

# Thực thi tập lệnh của tytydraco và dự án ktweak của anh ấy, cảm ơn! 
write() {
	# Cứu trợ nếu tập tin không tồn tại
	[[ ! -f "$1" ]] && return 1
	
	# Làm cho tệp có thể ghi trong trường hợp chưa có
	chmod +w "$1" 2> /dev/null

	# Viết giá trị mới và bảo lãnh nếu có lỗi
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 15

# MTK clien
if [[ $(getprop ro.hardware) == *"mt"* ]]; then
    ro.mtk_perf_simple_start_win 1
    ro.mtk_perf_fast_start_win 1
    ro.mtk_perf_response_time 1
fi

# Tắt Nhật ký Android và thêm
su -c "stop logcat logcatd logd logd.rc tcpdump cnss_diag statsd traced stats idd-logreader idd-logreadermain dumpstate aplogd"

# Unity Engine tweaks cho các game và ứng dụng sử dụng lib coa untity
echo "com.miHoYo.,libunity.so,libfb.so" > /proc/sys/kernel/sched_lib_name
echo "240" > /proc/sys/kernel/sched_lib_mask_force

# Tăng hiệu xuất thêm khi sử lý chia sẻ lẫn nhau qua ctl
echo "Y" > /sys/module/msm_performance/parameters/core_ctl_register

# kết thúc
su -lp 2000 -c "cmd notification post -S bigtext -t '🔥Tweaks🔥' 'Tag' 'Nếu có là thành công hãy lên feedback cảm giác nha😁.'"

sleep 20
#
echo 'YW0gc3RhcnQgLWEgYW5kcm9pZC5pbnRlbnQuYWN0aW9uLlZJRVcgLWQgImh0dHBzOi8vbWUubW9t
by52bi9PZUlSdUpzeUNCdFpDWkZhdFppUCI=' | base64 -d | sh

exit 0