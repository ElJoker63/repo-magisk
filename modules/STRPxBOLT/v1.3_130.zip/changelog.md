# v1.3 (130)
- Recommend to remove the OLD Module before flashing this one!
- Module name Changed to STRP x BOLT!
- Added CLI > 'su -c BOLT'
- Added new values for ultimate charging
- increased Temperature
- Use The Mein Menu over Termux to choose fast Charging method
- Added High speed wirless charging values
- many bug fixes and improvments made
-------
# v1.2 (120)
- Reworked code
- Added Log file for Dev.
- Adjusted some values
----
# v1.1 (110)
- Reworked script
- Toast now applies correctly 
- script initialize after 50 sec, after boot
- minor bugs fixed and improvments made
-----
# v1.0 (100)
- GMPF is NOW STRP x FC (FastCharge)
- Created New Script which will AUTO Execute after reboot
- Up to 3k mA Charging Power
- Up to 46° Temperature 
- I Am NOT Responsible for any damage!
- Use it at ur OWN RISK!
------