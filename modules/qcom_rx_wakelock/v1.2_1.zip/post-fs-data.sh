#!/system/bin/sh
MODDIR=${0%/*}

directory="/vendor/firmware/"
search_file="wifi.cfg"
insert_content="# disable qcom_rx_wakelock\nrx_wakelock_timeout 0\n"
save_directory="$MODDIR/system"
#corrected by @LeanHijosdesusMadres
target_file=$(find "$directory" -name "$search_file")

if [ -z "$target_file" ]; then
    exit
else
    file_directory=$(dirname "$target_file")
    save_file_directory="$save_directory${file_directory#$directory}"
    mkdir -p "$save_file_directory"
    save_file="$save_file_directory/${target_file##*/}"
    cp "$target_file" "$save_file.tmp"
    echo -e "\n$insert_content" >> "$save_file.tmp"
    mv "$save_file.tmp" "$save_file"
fi