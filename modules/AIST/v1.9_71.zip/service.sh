# Service controller script

resetprop -p --delete media.resolution.limit.16bit
resetprop -p --delete media.resolution.limit.24bit
resetprop -p --delete media.resolution.limit.32bit
resetprop -p --delete media.resolution.limit.64bit
