#!/system/bin/sh

resetprop -n persist.radio.noril 1