# SomcGameEnhancer Upgrade

Upgrade SomcGameEnhancer for Old Xperia Devices , Official Android 12 ROM only

## Included apps

- [SomcGameEnhancer](https://www.apkmirror.com/apk/sony-mobile-communications/game-enhancer/)
- [SomcGameEnhancerAPI](https://www.apkmirror.com/apk/sony-mobile-communications-inc/ge-subsystem-2/)
- [SomcGameEnhancerBrowser](https://www.apkmirror.com/apk/sony-mobile-communications/search-function/)
- [SomcGameEnhancerMonitor](https://www.apkmirror.com/apk/sony-mobile-communications/subsystem/)

## Supported devices:

- Xperia 1 II
- Xperia 5 II
- Xperia 10 II 
- Xperia 1 III 
- Xperia 5 III 
- Xperia 10 III 
- Xperia PRO-I

## More

If you need to upgrade other apps, download the apks from [ApkMirror](https://www.apkmirror.com/apk/sony-mobile-communications-inc/). You can install them directly, but they are not guaranteed to work.

- [Cinema Pro](https://www.apkmirror.com/apk/sony-mobile-communications/cinema-pro/)
- [Music Pro](https://www.apkmirror.com/apk/sony-corporation/music-pro/)
- [Photography Pro](https://www.apkmirror.com/apk/sony-mobile-communications/sony-photography-pro/)
- [Videography Pro](https://www.apkmirror.com/apk/sony-mobile-communications/videography-pro/)