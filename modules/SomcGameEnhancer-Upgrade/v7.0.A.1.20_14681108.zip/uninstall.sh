# 这个脚本会在删除模块的时候执行

pm clear com.sonymobile.gameenhancer
pm clear com.sonymobile.gameenhancer.api
pm clear com.sonymobile.gameenhancer.monitor
pm clear com.sonymobile.gameenhancer.browser
