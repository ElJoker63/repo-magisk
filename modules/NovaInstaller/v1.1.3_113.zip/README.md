# NovaInstaller
Installs the Nova Launcher to ``/system/app/`` on Android. Requires you to have Magisk v20.4 or higher, and it works with Android 8.0+!
## Why?
Well, it can be used in order to easily make Nova Launcher act like the default launcher, and having it for every user on the device by default. This is handy in some cases where you share a device with multiple users, but it can also have other reasons.
