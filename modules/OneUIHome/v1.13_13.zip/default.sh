am start-activity -c android.intent.category.HOME android/com.android.internal.app.ResolverActivity
