pm set-home-activity com.sec.android.app.launcher
sleep 1
am start-activity -a android.intent.action.MAIN -c android.intent.category.HOME
