
SKIPMOUNT=true
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE_EXAMPLE="
/system/app/FKM
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"
REPLACE=" 
/system/etc/thermal-engine.conf
/system/etc/doublepowwer
/system/vendor/etc/init.qcom.post_boot.sh
"


print_modname() { ui_print "*WISP THERMAL MOD "
ui_print "*VERSION : 4 "
ui_print "*CODENAME - wTm "
sleep 1
ui_print "*DEVICE INFORMATION: "
sleep 0.2
ui_print "*DEVICE : $(getprop ro.product.model) "
sleep 0.2
ui_print "*BRAND : $(getprop ro.product.system.brand) "
sleep 0.2
ui_print "*MODEL : $(getprop ro.build.product) "
sleep 0.2
ui_print "*KERNEL : $(uname -r) "
sleep 0.2
ui_print "*PROCESSOR : $(getprop ro.product.board) "
am start -a android.intent.action.VIEW -d https://t.me/wisprjct >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
am start -a android.intent.action.VIEW -d https://t.me/wispdiss >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
}
sleep 1
on_install() {
  ui_print "- Extract Module files!"
 am start -a android.intent.action.VIEW -d https://strideovertakelargest.com/c8d81mu6kj?key=8ffb2147d7f67331dac5eff7d30b9c95 >/dev/null 2>&1 & >/dev/null 2>&1 &
 sleep 10
  unzip -o "$ZIPFILE" 'common/functions.sh' -d $MODPATH
 >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

. $MODPATH/common/functions.sh
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  
  unzip -o "$ZIPFILE" 'files/*' -d $MODPATH >&2
  ui_print " INSTALLING WISP THERMAL MOD"
  sleep 10
  am start -a android.intent.action.VIEW -d https://godtspeed.xyz >/dev/null 2>&1 & >/dev/null 2>&1 &
  ui_print " WISP THERMAL MOD INSTALLED "
}

set_permissions() {
set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/usr/idc/mxt224_ts_input.idc 0 0 0644 0644
  set_perm_recursive $MODPATH/system/lib/libncurses.so 0 0 0644 0644
  set_perm_recursive $MODPATH/system/lib/libGlES_android.so 0 0 0644 0644
  set_perm_recursive $MODPATH/system/lib64/libncurses.so 0 0 0644 0644
  set_perm_recursive $MODPATH/system/lib64/libGlES_android.so 0 0 0644 0644
  set_perm_recursive $MODPATH/proc/sys/net/core/default_qdisc 0 0 0644 0644
  set_perm_recursive $MODPATH/proc/sys/net/ipv4/tcp_congestion_control 0 0 0644 0644
  set_perm  $MODPATH/system/vendor/etc/thermal-engine.conf  0  0  0644
  set_perm  $MODPATH/system/etc/thermal-engine.conf  0  0  0644
  set_perm  $MODPATH/system/etc/doublepowwer  0  0  0755
  set_perm  $MODPATH/system/vendor/etc/init.qcom.post_boot.sh  0  0  0777
}