const { Log } = require("android");
Log.i("Node-Log-Test", "Initial logger initialized");
