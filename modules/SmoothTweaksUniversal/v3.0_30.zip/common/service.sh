#!/system/bin/sh

#functions
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}
# CpuBoost
echo "0:0 4:0" > /sys/module/cpu_boost/parameters/topkek_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '0:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '1:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '2:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '3:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '4:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '5:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '6:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '7:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms

# Sync before execute to avoid crashes
sync

HRTICK() { write /sys/kernel/debug/sched_features HRTICK }

DISABLE_DEBUGGING() {
    for i in /sys/block/*/queue/iostats
    do
    echo 0 > $i
    done 
    
    for i in /sys/module/*/parameters/debug_mask
    do 
    echo 0 > $i
    done
    
    for i in /sys/module/*/parameters/debug_level 
    do 
    echo 0 > $i
    done
    
    if [ $(getprop init.svc.logd) = running ]; then
    stop logd
    fi 
    
    if [ $(getprop init.svc.statsd) = running ]; then
    stop statsd
    fi 
    
    if [ $(getprop init.svc.traced) = running ]; then
    stop traced
    fi
    
    write /proc/sys/fs/dir-notify-enable 0
    
    write /proc/sys/kernel/hung_task_timeout_secs 0
    
    write /proc/sys/vm/stat_interval 10
    
    write /sys/module/printk/parameters/console_suspend Y
    
    write /proc/sys/kernel/printk_devkmsg off
    
    write /proc/sys/kernel/printk 0 0 0 0
    
    write /sys/module/printk/parameters/cpu N
    
    write /sys/kernel/printk_mode/printk_mode 0
    
    write /sys/module/printk/parameters/ignore_loglevel Y
    
    write /sys/module/printk/parameters/pid N
    
    write /sys/module/printk/parameters/time N
    
    write /sys/kernel/debug/debug_enabled N
    
    write /proc/sys/kernel/sched_schedstats 0
    
    write /proc/sys/vm/oom_dump_tasks 0
    
    write /proc/sys/vm/block_dump 0
    
    write /sys/module/subsystem_restart/parameters/enable_ramdumps 0

    write /sys/module/rmnet_data/parameters/rmnet_data_log_level 0
    
    write /sys/kernel/tracing/tracing_on 0
    
    write /sys/kernel/debug/tracing/tracing_on 0
    
    write /proc/sys/kernel/compat-log 0
    
    write /sys/module/logger/parameters/log_enabled 0
    
    write /proc/sys/debug/exception-trace 0
    
    write /sys/module/debug/parameters/enable_event_log 0
    
    write /sys/module/logger/parameters/enabled 0
    
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv 0
       
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt 0
    
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd 0
    
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr 0
    
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem 0
    
    write /sys/module/mali/parameters/mali_debug_level 0
    
    write /sys/module/ext4/parameters/mballoc_debug 0
    
    write /sys/module/rpm_smd/parameters/debug_mask 0
    
    write /sys/module/msm_show_resume_irq/parameters/debug_mask 0
    write /sys/module/rmnet_data/parameters/rmnet_data_log_level 0
    write /sys/module/ip6_tunnel/parameters/log_ecn_error N
    
    write /sys/module/mmc_core/parameters/use_spi_crc 0
}

BTFST() {
    #reset read ahead and nr requests to default after boot
    for i in /sys/block/*/queue/read_ahead_kb
    do
    echo 128 > $i
    done
    
    for i in /sys/block/*/queue/nr_requests
    do
    echo 128 > $i
    done
}

    sleep 5

#main program
HRTICK
DISABLE_DEBUGGING
BTFST

MODDIR=${0%/*}

for i in /sys/module/*/parameters/debug_mask
do 
echo 0 > $i
done

for i in /sys/module/*/parameters/debug_level 
do 
echo 0 > $i
done

if [ $(getprop init.svc.logd) = running ]; then
stop logd
fi 

if [ $(getprop init.svc.statsd) = running ]; then
stop statsd
fi 

if [ $(getprop init.svc.traced) = running ]; then
stop traced
fi

for i in /sys/block/*/queue/read_ahead_kb
do
echo 128 > $i
done

for i in /sys/block/*/queue/nr_requests
do
echo 128 > $i
done

echo 1 > /sys/devices/platform/soc/1d84000.ufshc/clkgate_enable

echo 1 > /sys/devices/platform/soc/1d84000.ufshc/clkscale_enable

echo 1 > /sys/devices/platform/soc/1d84000.ufshc/hibern8_on_idle_enable

sync && echo 3 > /proc/sys/vm/drop_caches

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53

echo '0' > /proc/sys/net/ipv4/ip_no_pmtu_disc;
echo '0' > /proc/sys/net/ipv4/tcp_ecn;
echo '0' > /proc/sys/net/ipv4/tcp_timestamps;
echo '1' > /proc/sys/net/ipv4/route.flush;
echo '1' > /proc/sys/net/ipv4/tcp_rfc1337;
echo '1' > /proc/sys/net/ipv4/tcp_tw_reuse;
echo '1' > /proc/sys/net/ipv4/tcp_sack;
echo '1' > /proc/sys/net/ipv4/tcp_fack;
echo '1' > /proc/sys/net/ipv4/tcp_tw_recycle;
echo '1' > /proc/sys/net/ipv4/tcp_window_scaling;
echo '6' > /proc/sys/net/ipv4/tcp_probe_threshold;
echo '10' > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo '30' > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo '5' > /proc/sys/net/ipv4/tcp_fin_timeout;
echo '80' > /proc/sys/net/ipv4/tcp_pacing_ca_ratio;
echo '150' > /proc/sys/net/ipv4/tcp_pacing_ss_ratio;
echo '400' > /proc/sys/net/ipv4/tcp_probe_interval;
echo "404480" > /proc/sys/net/core/wmem_max;
echo "404480" > /proc/sys/net/core/rmem_max;
echo "256960" > /proc/sys/net/core/rmem_default;
echo "256960" > /proc/sys/net/core/wmem_default;
echo "4096,16384,404480" > /proc/sys/net/ipv4/tcp_wmem;
echo "4096,87380,404480" > /proc/sys/net/ipv4/tcp_rmem; 
echo '404480 404480 404480' > /proc/sys/net/ipv4/tcp_mem;
echo 'Y' > /sys/module/module/parameters/lock_wlanmodule;
chown wifi wifi /sys/module/wlan/parameters/fwpath;
cat /proc/sys/net/ipv4/tcp_allowed_congestion_control;
echo 'bbr westwood cubic reno' > /proc/sys/net/ipv4/tcp_allowed_congestion_control;
cat /proc/sys/net/ipv4/tcp_available_congestion_control;
echo 'bbr westwood cubic reno bic cdg dctcp hybla htcp vegas veno lp yeah illinois' > /proc/sys/net/ipv4/tcp_available_congestion_control;
cat /proc/sys/net/ipv4/tcp_congestion_control;
sudo sysctl -w net.ipv4.tcp_congestion_control=bbr
sudo sysctl -w net/ipv4/tcp_congestion_control=bbr
echo 'bbr' > /proc/sys/net/ipv4/tcp_congestion_control;
restorecon -R /proc/sys/net/ipv4/tcp_congestion_control;

#Fstrim
fstrim /data;
fstrim /system;
fstrim /cache;
fstrim /vendor;
fstrim /product;

# Exit
exit 0