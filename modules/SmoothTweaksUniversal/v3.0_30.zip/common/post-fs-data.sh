#!/system/bin/sh
MODDIR=${0%/*}

#function(s)
BTFST() {
    # increase read ahed and nr requests to optimize throughput
    for i in /sys/block/*/queue/read_ahead_kb
    do
    echo 2048 > $i
    done
    
    for i in /sys/block/*/queue/nr_requests
    do
    echo 512 > $i
    done
}

#main program
BTFST

MODDIR=${0%/*}

for i in /sys/block/*/queue/iostats
do
echo 0 > $i
done

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/clkgate_enable

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/clkscale_enable

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/hibern8_on_idle_enable

if [ -a /system/etc/resolv.conf ]; then
	mkdir -p $MODDIR/system/etc/
	printf "nameserver 8.8.8.8\nnameserver 1.1.1.1" >> $MODDIR/system/etc/resolv.conf
	chmod 644 $MODDIR/system/etc/resolv.conf
fi

find /sys/devices/system/cpu -maxdepth 1 -name 'cpu?' | while IFS= read -r cpu; do
  max_freq=$(read_file_unlock "$cpu/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed '/^$/d' | tail -n 1)
  write_file_lock "$cpu/cpufreq/scaling_min_freq" "$max_freq"
  write_file_lock "$cpu/cpufreq/scaling_max_freq" "$max_freq"
done

max_freq=$(read_file_unlock "/sys/class/kgsl/kgsl-3d0/freq_table_mhz" | tr " " "\n" | sort -n | sed '/^$/d' | tail -n 1)
write_file_lock "/sys/class/kgsl/kgsl-3d0/min_clock_mhz" "$max_freq"
write_file_lock "/sys/class/kgsl/kgsl-3d0/max_clock_mhz" "$max_freq"
write_file_lock "/sys/class/kgsl/kgsl-3d0/throttling" "0"
find /sys/kernel/debug/kgsl/kgsl-3d0/ -name '*log*' | while IFS= read -r log; do
wr
write_file_lock "$log" "0"
done
