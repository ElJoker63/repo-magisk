<p align="center">
<img width="900" height="150" src="https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/CustomizedNavbar/main/assets/0-1-1-choose.png">
<img width="900" height="150" src="https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/CustomizedNavbar/main/assets/0-1-1-result.png">
</p>

#
#

<p align="center">
<img width="900" height="150" src="https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/CustomizedNavbar/main/assets/1-0-0-choose.png">
<img width="900" height="150" src="https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/CustomizedNavbar/main/assets/1-0-0-result.png">
</p>

 #
 #

<p align="center">
<img width="900" height="150" src="https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/CustomizedNavbar/main/assets/1-1-0-choose.png">
<img width="900" height="150" src="https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/CustomizedNavbar/main/assets/1-1-0-result.png">
</p>

#
#

<p align="center">
<img width="900" height="150" src="https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/CustomizedNavbar/main/assets/1-1-1-choose.png">
<img width="900" height="150" src="https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/CustomizedNavbar/main/assets/1-1-1-result.png">
</p>
