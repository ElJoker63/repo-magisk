#!/bin/sh

SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"
sleep 2

ui_print " ————————————————————————————————— "
  ui_print "       ♨ Kaguya Gaming AI ♨      "
  ui_print " ———————————————————————————————— "
  ui_print " ———————————————————————————————  "
 sleep 2
  ui_print "  Intalling--------------- "
sleep 2
  ui_print " "
sleep 2
  ui_print "Joined My Channel For Next Update "
  ui_print " |||||||||||||||||||||||||||||||  "
  ui_print "  @ZxyonQiy | @ZxyonQiyChnnel  "

sleep 2

ui_print "- Extracting module files"
unzip -o "$ZIPFILE" 'gameacc.txt' -d $MODPATH >&2
mkdir -p $MODPATH/system/bin
unzip -o "$ZIPFILE" 'Gaming' -d $MODPATH/system/bin >&2
ui_print "- Detecting installed game"

sleep 2

counter=1
package_list=$(cmd package list packages | cut -f 2 -d ":")  
while IFS= read -r gameacc || [[ -n "$gameacc" ]]; do
line=$(echo "$gameacc" | awk '!/ /')
    if echo "$package_list" | grep -q "$line"; then
        ui_print "  $counter. $line"
        counter=$((counter + 1))
    else
        sed -i "/$line/d" "$MODPATH/gameacc.txt"
    fi
done < "$MODPATH/gameacc.txt"
ui_print "Jika Game yang anda gunakan tidak tertulis"
ui_print "  Edit di gameacc.txt dan pasang ulang"

sleep 2

chmod +x $MODPATH/system/bin/Gaming

sleep 2
  ui_print "===========[Success]============= "