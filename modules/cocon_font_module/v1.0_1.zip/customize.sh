. $MODPATH/ohmyfont.sh

### INSTALLATION ###

ui_print '  -- -- Driving till footpath 🚘'

ui_print ' -- -- Killed black buck successful'
prep

ui_print '+ Configure'
config

ui_print '+ Font'
install_font

src

ui_print '+ Rom'
rom
fontspoof
finish
