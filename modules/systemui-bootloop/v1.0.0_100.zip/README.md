# systemui-bootloop
Fixes SystemUI bootloops.

## About
Fixes SystemUI bootloops by detecting when SystemUI crashes (due to a Magisk module such as Substratum,) and reboots your device into safe mode automatically to disable Magisk so you can correct the faulty module.

## Requirements
This module has not been tested below Magisk v24.1, so try at your own risk if you are not updated.

## Installation
Grab the latest release from the [releases page](https://github.com/tsukimio/systemui-bootloop/releases) and Flash using Magisk manager.

--- 
**Want to get information and updates on this Magisk module along with my other Magisk modules? Join my [Telegram announcement channel](https://t.me/tsukimio).**
