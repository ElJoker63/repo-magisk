# Initial Release
This is the first release that is tested to work

## Notes
#### Quirks: 
* This module currently takes around 30 seconds to detect that SystemUI is bootlooping. This will be fixed in a later release.
* Please disable this module if you are going to reboot SystemUI, as it may detect it and disable all Magisk modules. (example: enabling / disabling overlays for SystemUI shortly after booting up your device. You should most likely be fine if you wait a few minutes after boot before doing this.
