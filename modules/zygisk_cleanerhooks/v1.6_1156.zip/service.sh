#!/system/bin/sh
MODDIR=${0%/*}

BUILD_TYPE=release
SH_PATH="/data/user_de/0/me.gm.cleaner/files/start.sh"
SOURCE_DIR_PATH="/data/user_de/0/me.gm.cleaner/files/source_dir"

if [ -f "$SH_PATH" ] && [ -f "$SOURCE_DIR_PATH" ]; then
  SOURCE_DIR=$(cat "$SOURCE_DIR_PATH")
  if [ -f "$SOURCE_DIR" ]; then
    sh "$SH_PATH" --apk="$SOURCE_DIR"
  fi
fi
