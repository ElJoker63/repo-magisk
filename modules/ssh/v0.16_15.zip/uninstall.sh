if ! test -e /data/ssh/KEEP_ON_UNINSTALL ; then
    rm -rf /data/ssh
fi
