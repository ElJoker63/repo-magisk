# tracing_off

## Description
Quick way to disable tracing

## Details:
- As detailed in /sys/kernel/tracing/README

## Support
- [GitHub](https://github.com/LeanxModulostk/tracing_off) 
- [Telegram Channel](https://t.me/modulostk)

## Special Thanks

• [Zackptg5 for the MMT-Ex template](https://github.com/Zackptg5)

• [Topjohnwu for making Magisk](https://github.com/topjohnwu)
