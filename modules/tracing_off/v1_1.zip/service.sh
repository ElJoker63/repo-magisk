sleep 40

su
echo 0 > tracing_on
exit 0
