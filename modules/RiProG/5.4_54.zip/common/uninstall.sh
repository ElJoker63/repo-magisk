#!/bin/sh

rm /storage/emulated/0/Android/AI.log