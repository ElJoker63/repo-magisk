#!/bin/sh

rm /data/media/0/Android/AI.log