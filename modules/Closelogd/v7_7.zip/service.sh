#!system/bin/sh
#Sourced from the scene (thanks to @头露基基) (thanks to Kuan @杀鲸 for the test)
sleep 5

am kill logd
killall -9 logd

am kill logd.rc
killall -9 logd.rc

#Release cache on boot (try cleaning)
sleep 10
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory

#clear wifi logs
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs