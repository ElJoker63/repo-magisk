LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=false
SKIPMOUNT=false
print_modname() {
 ui_print "         Module installation in progress               "
}
on_install() {
 ui_print "- File being released"
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}