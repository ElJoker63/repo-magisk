# Changes

## v1.2
- Repo change (Magisk-Modules-Alt-Repo)

## v1.1
- Bug fixes

## v1.0
- Initial release