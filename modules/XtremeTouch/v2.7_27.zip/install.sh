SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"
sleep 2
ui_print " ————————————————————————————————— "
  ui_print "      ⚡ Xtreme Touch 2.7 ⚡     "
  ui_print " ———————————————————————————————— "
 sleep 2
  ui_print " Intalling Touch Module------ "
sleep 2
ui_print " "
sleep 2
ui_print "-----------[succsess]-------------- "
sleep 2
  ui_print "Joined My Channel For Next Update "
  ui_print " |||||||||||||||||||||||||||||||  "
  ui_print "  @ZxyonQiy | @ZxyonQiyChnnel  "