#!/bin/sh
wok=/data/adb/modules
if [[ ! -d "$wok/xtremetouch_module" ]]; then
settings put global animator_duration_scale 1.0
settings put global transition_animation_scale 1.0
settings put global window_animation_scale 1.0
settings delete secure multi_press_timeout
settings delete secure long_press_timeout
settings delete global block_untrusted_touches
rm -rf /sdcard/XtremeUninstall.sh
echo "Done"
else
echo
echo
exit 1
fi