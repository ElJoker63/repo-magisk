#!/bin/sh
#klo mau ambil ya credit lah cok @ZxyonQiy

#functions
write_code() {
  if [ -f "$1" ]; then
    if [ ! -w "$1" ]; then
      chmod +w "$1"
    fi
     echo "$2" > "$1"
	fi
}

while [ -z "$(resetprop sys.boot_completed)" ]; do
    sleep 5
done

write_code "settings put secure multi_press_timeout" "150"
write_code "settings put secure long_press_timeout" "150"
write_code "settings put global animator_duration_scale" "0.0"
write_code "settings put global transition_animation_scale" "0.0"
write_code "settings put global window_animation_scale" "0.0"
write_code "settings put global block_untrusted_touches" "0"

for i in /proc/touchpanel; do
write_code "$i/game_switch_enable" "1"
write_code "$i/oppo_tp_direction" "1"
write_code "$i/oppo_tp_limit_enable" "0"
write_code "$i/oplus_tp_limit_enable" "0"
write_code "$i/oplus_tp_direction" "1"

if
elif [[ -e "/sys/devices/virtual/touch/touch_dev/bump_sample_rate" ]]; then
echo "1" > "/sys/devices/virtual/touch/touch_dev/bump_sample_rate"
elif [[ -e "/sys/touchpanel/double_tap" ]]; then
echo "1" > "/sys/touchpanel/double_tap"
elif [[ -e "/sys/module/msm_performance/parameters/touchboost" ]]; then
echo "1" > "/sys/module/msm_performance/parameters/touchboost"
elif [[ -e "/sys/power/pnpmgr/touch_boost" ]]; then
echo "1" > "/sys/power/pnpmgr/touch_boost"
elif [[ -e "/sys/class/input/input0/bump_sample_rate" ]]; then
echo "1" > "/sys/class/input/input0/bump_sample_rate"
elif [[ -e "/sys/class/input/input1/bump_sample_rate" ]]; then
echo "1" > "/sys/class/input/input1/bump_sample_rate"
elif [[ -e "/sys/class/input/input2/bump_sample_rate" ]]; then
echo "1" > "/sys/class/input/input2/bump_sample_rate"
elif [[ -e "/sys/class/input/input3/bump_sample_rate" ]]; then
echo "1" > "/sys/class/input/input3/bump_sample_rate"
elif [[ -e "/sys/class/input/input4/bump_sample_rate" ]]; then
echo "1" > "/sys/class/input/input4/bump_sample_rate"
elif [[ -e "/sys/class/input/input5/bump_sample_rate" ]]; then
echo "1" > "/sys/class/input/input5/bump_sample_rate"
elif [[ -e "/proc/hps/boost_on/parameters/MTKboost" ]]; then
echo "1" > "/proc/hps/boost_on/parameters/MTKboost"
fi
}

exit 0